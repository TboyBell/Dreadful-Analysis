# FINAL REPORT Q5 — RESULTS AND CONCLUSIONS DRAFT

## Results and conclusions

**RQ1.** Random forest was selected among the registered primary candidates for reproducing the FWI/FFMC-derived class designation. Mean leave-one-month-out balanced accuracy was 0.853 (SD 0.049), with pooled out-of-fold balanced accuracy 0.867; the decision tree (0.838) and logistic model (0.742) were lower under the registered primary comparison (Figure 4). The preregistered `Rain_any` logistic sensitivity reached 0.857 but was excluded from model selection; with only four folds and a difference of about 0.004, this does not demonstrate reliable superiority.

![](fig_4_rq1_lomo_balanced_accuracy.png)

**Figure 4.** Leave-one-month-out balanced accuracy.

Held-out random-forest permutation importance identified Rain as dominant (0.277 balanced-accuracy decrease), followed by RH (0.033), Temperature (0.025) and wind speed (−0.006). Standardised logistic odds ratios were Temperature 3.046, RH 0.517, wind speed 1.351 and Rain 0.007 (Figure 5). Rain’s coefficient was sensitive to sparse influential observations and is neither a stable physical effect nor causal.

![](fig_5_rq1_logistic_odds_ratios.png)

**Figure 5.** Standardised logistic odds ratios.

**RQ2.** Region was associated with designation in R0 (OR 1.962; 95% CI 1.173–3.280), became approximately null after Temperature/RH adjustment in R1 (OR 0.995), and was uncertain in R2 (OR 1.724; 95% CI 0.830–3.577). Thus, regional association did not persist robustly across weather-adjusted specifications. Exploratory R3 produced extreme, unstable Region × Rain estimates from sparse, near-separating rainfall patterns and should not be treated as precise effects.

**RQ3.** Figures C and D showed that both regions had their highest fire-designation proportions in August, with lower September proportions. Weekly mean FWI shared a late-August peak followed by decline. These are descriptive designation and FWI patterns, not independently observed fire-occurrence rates or forecasts.

Further work should assess generalisability across additional seasons and regions, using independently observed wildfire outcomes.

---

## Draft control record

**Exact word count:** 270 words, including the section heading and both substantive figure captions. Markdown image-link syntax, the document title and this control record are excluded.

**Frozen evidence files used:**
- `04_Phase_4_Modelling_Frozen/PHASE4_FROZEN_SUMMARY.md`
- `05_Audit_Records/PHASE4B_COMPUTATIONAL_AUDIT.md`
- `04_Phase_4_Modelling_Frozen/metric_summary.csv`
- `04_Phase_4_Modelling_Frozen/pooled_oof_metrics.csv`
- `04_Phase_4_Modelling_Frozen/model_selection_decision.json`
- `04_Phase_4_Modelling_Frozen/rain_binary_sensitivity_metrics.csv`
- `04_Phase_4_Modelling_Frozen/permutation_importance_summary.csv`
- `04_Phase_4_Modelling_Frozen/logistic_full_data_coefficients.csv`
- `04_Phase_4_Modelling_Frozen/rq2_specification_results.csv`
- `04_Phase_4_Modelling_Frozen/rq2_interaction_sensitivity.csv`
- `04_Phase_4_Modelling_Frozen/fig_4_rq1_lomo_balanced_accuracy.png`
- `04_Phase_4_Modelling_Frozen/fig_5_rq1_logistic_odds_ratios.png`
- `03_Phase_3_EDA_Frozen/PHASE3_FROZEN_SUMMARY.md`
- Previously approved Figures C and D, referenced but not duplicated
- `FINAL_REPORT_EVIDENCE_MAP.md`
- Frozen assessment brief, rubric and answer template

**Frozen numerical values used:**
- RQ1: random-forest mean balanced accuracy 0.853; fold SD 0.049; pooled out-of-fold balanced accuracy 0.867; decision tree 0.838; logistic model 0.742; `Rain_any` sensitivity 0.857.
- Permutation importance: Rain 0.2766 (rounded 0.277); RH 0.0334 (0.033); Temperature 0.0247 (0.025); wind speed −0.0060 (−0.006).
- Standardised logistic odds ratios: Temperature 3.046; RH 0.517; wind speed 1.351; Rain 0.00721 (rounded 0.007).
- RQ2: R0 region OR 1.962, 95% interval 1.173–3.280; R1 OR 0.995; R2 OR 1.724, interval 0.830–3.577.
- RQ3: frozen qualitative August, September and late-August FWI patterns from Phase 3; no new values estimated.

**Citations used:** None. This section reports only frozen project results.

**Compliance check:**
- RQ1, RQ2 and RQ3 are all answered explicitly.
- The section is within the 300-word maximum, with captions counted conservatively.
- `Rain_any` is identified as a preregistered sensitivity excluded from model selection.
- Rain’s logistic estimate and R3 are qualified as sparse-data-sensitive or unstable and non-causal.
- No real-wildfire prediction, future-forecasting or causal claim appears.
- Figures 4 and 5 appear once; Figures C and D are referred to but not duplicated.
- No method, statistic, analytical finding or external source was added.
