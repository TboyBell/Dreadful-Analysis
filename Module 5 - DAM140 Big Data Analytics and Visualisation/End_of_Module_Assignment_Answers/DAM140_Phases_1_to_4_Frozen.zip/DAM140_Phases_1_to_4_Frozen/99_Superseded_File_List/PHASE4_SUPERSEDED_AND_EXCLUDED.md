# Phase 4 Superseded and Excluded Files

The following Phase 4 working or intermediate items are not implementation authorities and are excluded from the final frozen release except where a final audit record explicitly quotes their history.

| Item | Status and permitted use |
|---|---|
| Claude's original Phase 4A proposal | Failed initial design audit; audit history only; not authorised for implementation or report evidence |
| ChatGPT's initial Phase 4A audit | Audit-history input to correction; not the final implementation authority |
| Earlier pre-correction preregistration | Superseded; audit history only |
| `PHASE4A_REVISED_PREREGISTRATION_v2.md` | Working correction version; audit history only after canonicalisation |
| `PHASE4A_REVISED_PREREGISTRATION.md` copies predating final canonicalisation | Superseded by the hash-verified canonical file included under `04_Phase_4_Modelling_Frozen/` |
| `PHASE4B_WORKING_PACKAGE.zip` | Working package; superseded by the frozen Phase 4 folder and final Phase 1–4 archive |
| `PHASE4_FROZEN_SUBSET.zip` | Temporary blocked-release subset; superseded by the final Phase 1–4 archive |
| `PHASE4_RELEASE_BLOCKER_REPORT.md` | Historical blocked-assembly report; no longer controlling after the missing authoritative inputs were restored |
| `__pycache__/` and `.pyc` files | Runtime artefacts; removed and prohibited from the frozen release |
| Chat-platform-transcoded Figure 4 or Figure 5 copies | Not authoritative; only the original code-generated PNG bytes in the frozen Phase 4 folder are authorised |

## Sole authority

The only Phase 4A implementation authority is:

`04_Phase_4_Modelling_Frozen/PHASE4A_REVISED_PREREGISTRATION.md`

The final analytical authority is the audited content of `04_Phase_4_Modelling_Frozen/`, interpreted through `PHASE4_FROZEN_SUMMARY.md` and the final audit records.
