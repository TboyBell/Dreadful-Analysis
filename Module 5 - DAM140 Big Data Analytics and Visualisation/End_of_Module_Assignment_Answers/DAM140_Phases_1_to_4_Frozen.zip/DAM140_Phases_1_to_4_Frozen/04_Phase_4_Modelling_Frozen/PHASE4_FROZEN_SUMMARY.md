# Phase 4 — Frozen Summary

## Status

Phase 4A passed independent audit and the canonical preregistration was frozen. Phase 4B received **PASS WITH MINOR NON-BLOCKING CORRECTIONS** and was analytically accepted. The Phase 4B files were frozen after non-analytical package cleanup only. No model, prediction, metric, coefficient, permutation result, RQ2 result or figure was recalculated or regenerated during cleanup.

## Target and interpretation boundary

`Classes` is an FWI/FFMC-derived class designation, not independently observed wildfire incidence. The exact class-assignment thresholds are undocumented. Phase 4 results measure reproduction of this recorded designation and must not be presented as real-fire detection, wildfire forecasting, or causal physical effects.

## Audited RQ1 conclusions

- The random forest was selected among the registered primary candidates under the frozen preferred-model rule.
- Its mean four-fold leave-one-month-out balanced accuracy was approximately **0.853**.
- Its pooled out-of-fold balanced accuracy was approximately **0.867**.
- The separately labelled `Rain_any` logistic sensitivity performed similarly and slightly higher than the primary candidates on the reported balanced-accuracy summaries, but it was excluded from primary model selection exactly as preregistered.
- Rain was the dominant held-out random-forest permutation contribution.
- The logistic Rain coefficient is sensitive to sparse influential observations and must not be presented as a stable, precise, physical or causal effect estimate.

## Audited RQ2 conclusion

The regional result is specification-dependent. The R3 Region × Rain model is exploratory and too unstable for detailed odds-ratio interpretation. R3 must not be presented as a precise, causal or physically interpretable regional effect.

## RQ3

RQ3 remains based on the frozen Phase 3 descriptive findings and Figures C and D. No Phase 3 analysis or figure was regenerated during Phase 4.

## Integrity

- Original code-generated Figure 4 SHA-256: `2711a840931abbaa2ad119e9b8e28f2ef21911622b03c4e54f480cb9aa4f9908`
- Original code-generated Figure 5 SHA-256: `2c5dca9a6ef035278486b7cb1d657d983b42016bd426557a2b6020d05f28b1a6`
- Cleaned Phase 4B manifest SHA-256: `37ee807b5acedcffe56dad5f000c5a5b311ee8e850fe199434c74f7cadd66282`

Working versions and failed or intermediate preregistrations are superseded, retained only for audit history where applicable, and are not authorised for Phase 4B implementation or final-report analysis.
