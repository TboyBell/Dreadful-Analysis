#!/usr/bin/env python3
"""DAM140 Phase 4B implementation.

Implements the frozen canonical PHASE4A_REVISED_PREREGISTRATION.md exactly.
The target is an FWI/FFMC-derived class designation, not independently observed
wildfire incidence. This script evaluates out-of-month label reproduction only.
"""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import math
import os
import platform
import random
import shutil
import sys
import traceback
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import stats
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
import statsmodels
import statsmodels.api as sm

EXPECTED_VERSIONS = {
    "python": "3.13.5",
    "numpy": "2.3.5",
    "pandas": "2.2.3",
    "scipy": "1.17.0",
    "statsmodels": "0.14.6",
    "scikit-learn": "1.8.0",
    "matplotlib": "3.10.8",
}
THREAD_ENV = {
    "PYTHONHASHSEED": "140",
    "OMP_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
}
MASTER_SEED = 140
CANONICAL_PREREG_FILENAME = "PHASE4A_REVISED_PREREGISTRATION.md"
CANONICAL_PREREG_SHA256 = "13c6baf60706f49f8d450a74775849b36555a453ad881620653f638b0fb40d98"
PASS_DECISION = "PASS — Freeze Phase 4A and authorise Phase 4B"
INPUT_DATA_SHA256 = "9b24dd2ee6e5678ebb323ceb9b9e8d8f1d351df3974b80ca2ebf49d69a73da6a"
PHASE3_SUMMARY_SHA256 = "106f6f368bba10521329c1bfbb43e4abcf71ebb81abf8ca1e9f31d7cba933a14"
PHASE3_SCRIPT_SHA256 = "b5c1defcc4b333ad32b8e626eb3e78003a49e46ae8811f98ab017b4d7f9aae57"

REQUIRED_COLUMNS = [
    "day", "month", "year", "Temperature", "RH", "Ws", "Rain",
    "FFMC", "DMC", "DC", "ISI", "BUI", "FWI", "Classes", "Region",
    "record_repaired", "date",
]
PRIMARY_FEATURES = ["Temperature", "RH", "Ws", "Rain"]
SENSITIVITY_FEATURES = ["Temperature", "RH", "Ws", "Rain_any"]
CLASS_TO_INT = {"not fire": 0, "fire": 1}
INT_TO_CLASS = {0: "not fire", 1: "fire"}
THRESHOLD = 0.5
FOLDS = {
    "F06": {"month": 6, "name": "June"},
    "F07": {"month": 7, "name": "July"},
    "F08": {"month": 8, "name": "August"},
    "F09": {"month": 9, "name": "September"},
}
GAP_DATES = {
    "F06": ["2012-07-01", "2012-07-02", "2012-07-03"],
    "F07": ["2012-06-28", "2012-06-29", "2012-06-30", "2012-08-01", "2012-08-02", "2012-08-03"],
    "F08": ["2012-07-29", "2012-07-30", "2012-07-31", "2012-09-01", "2012-09-02", "2012-09-03"],
    "F09": ["2012-08-29", "2012-08-30", "2012-08-31"],
}
PERMUTATION_SEEDS = {"F06": 1406, "F07": 1407, "F08": 1408, "F09": 1409}

MODEL_NAMES = {
    "baseline": "majority_baseline",
    "logistic": "logistic_raw_rain",
    "tree": "decision_tree",
    "forest": "random_forest",
    "rain_any": "logistic_rain_any",
}

TREE_PARAMS = {
    "criterion": "gini",
    "splitter": "best",
    "max_depth": 3,
    "min_samples_split": 20,
    "min_samples_leaf": 10,
    "min_weight_fraction_leaf": 0.0,
    "max_features": None,
    "random_state": 140,
    "max_leaf_nodes": None,
    "min_impurity_decrease": 0.0,
    "class_weight": None,
    "ccp_alpha": 0.0,
    "monotonic_cst": None,
}
FOREST_PARAMS = {
    "n_estimators": 500,
    "criterion": "gini",
    "max_depth": 4,
    "min_samples_split": 10,
    "min_samples_leaf": 5,
    "min_weight_fraction_leaf": 0.0,
    "max_features": "sqrt",
    "max_leaf_nodes": None,
    "min_impurity_decrease": 0.0,
    "bootstrap": True,
    "oob_score": False,
    "n_jobs": 1,
    "random_state": 140,
    "verbose": 0,
    "warm_start": False,
    "class_weight": None,
    "ccp_alpha": 0.0,
    "max_samples": None,
    "monotonic_cst": None,
}

OUTPUT_PURPOSES = {
    "phase4b_modelling.py": "Single executable implementation of the passed Phase 4A pre-registration",
    "PHASE4B_MODEL_SPECIFICATION.json": "Exact predictors, folds, parameters, seeds, thresholds, metrics and failure rules",
    "PHASE4B_REQUIREMENTS.txt": "Pinned Phase 4B Python package versions",
    "PHASE4B_ENVIRONMENT.json": "Observed Python, package, platform and process-environment details",
    "input_checksums.csv": "Expected and observed hashes for authoritative and controlling inputs",
    "warnings_and_failures.csv": "Captured warnings, failures and actions",
    "fold_assignments.csv": "Primary and boundary-gap fold assignments for every source row",
    "baseline_training_counts.csv": "Fold-contained majority-class counts and decisions",
    "preprocessing_parameters.csv": "Training-fold and full-data scaling parameters",
    "oof_predictions.csv": "Out-of-fold classes and probabilities for every authorised model and sensitivity",
    "fold_metrics.csv": "Per-fold metrics and confusion counts",
    "metric_summary.csv": "Unweighted four-fold means and sample standard deviations",
    "pooled_oof_metrics.csv": "Separately labelled pooled out-of-fold metrics",
    "pooled_confusion_matrices.csv": "Pooled out-of-fold confusion matrices",
    "model_selection_decision.json": "Preferred-model eligibility, practical tie and final decision",
    "rain_binary_sensitivity_metrics.csv": "Separately labelled Rain_any logistic sensitivity results",
    "boundary_gap_sensitivity_metrics.csv": "Separately labelled three-day boundary-gap sensitivity results",
    "logistic_full_data_coefficients.csv": "Post-validation standardised logistic coefficients and model-based intervals",
    "permutation_importance_by_fold.csv": "Held-out random-forest permutation importance by fold and repeat",
    "permutation_importance_summary.csv": "Within-fold and across-fold permutation-importance summaries",
    "rq2_centering_values.csv": "Full-data means used for RQ2 centring",
    "rq2_specification_results.csv": "RQ2 primary logistic specification results R0–R2",
    "rq2_interaction_sensitivity.csv": "Exploratory R3 interaction and planned likelihood-ratio test",
    "fig_4_rq1_lomo_balanced_accuracy.png": "Approved Phase 4 Figure 4: fold-level balanced accuracy",
    "fig_5_rq1_logistic_odds_ratios.png": "Approved Phase 4 Figure 5: standardised logistic odds ratios",
    "PHASE4B_README.md": "Execution, inputs, outputs, PASS authority and interpretation restrictions",
}


def iso_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def json_safe(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        if np.isnan(value):
            return None
        return float(value)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    return value


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(json_safe(obj), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, df: pd.DataFrame) -> None:
    df.to_csv(path, index=False, float_format="%.15g")


def append_event(events: list[dict[str, Any]], stage: str, variant: str = "", fold_id: str = "", model: str = "", category: str = "", message: str = "", action: str = "") -> None:
    events.append({
        "timestamp": iso_now(),
        "stage": stage,
        "variant": variant,
        "fold_id": fold_id,
        "model": model,
        "category": category,
        "message": message,
        "action": action,
    })


def capture_warnings(events: list[dict[str, Any]], stage: str, variant: str, fold_id: str, model: str, fn: Callable[[], Any]) -> Any:
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = fn()
    for w in caught:
        append_event(
            events,
            stage=stage,
            variant=variant,
            fold_id=fold_id,
            model=model,
            category=w.category.__name__,
            message=str(w.message),
            action="Captured; specification unchanged",
        )
    return result


def get_versions() -> dict[str, str]:
    return {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "statsmodels": statsmodels.__version__,
        "scikit-learn": sklearn.__version__,
        "matplotlib": matplotlib.__version__,
    }


def validate_environment(events: list[dict[str, Any]]) -> dict[str, Any]:
    observed = get_versions()
    errors: list[str] = []
    for key, expected in EXPECTED_VERSIONS.items():
        if observed.get(key) != expected:
            errors.append(f"Version mismatch for {key}: expected {expected}, observed {observed.get(key)}")
    observed_env = {k: os.environ.get(k) for k in THREAD_ENV}
    for key, expected in THREAD_ENV.items():
        if observed_env.get(key) != expected:
            errors.append(f"Environment mismatch for {key}: expected {expected}, observed {observed_env.get(key)!r}")
    if Path(os.environ.get("MPLCONFIGDIR", "")).resolve() != (WORKDIR / ".mplconfig").resolve():
        errors.append(f"MPLCONFIGDIR must be {WORKDIR / '.mplconfig'}, observed {os.environ.get('MPLCONFIGDIR')!r}")

    dt_sig = inspect.signature(DecisionTreeClassifier)
    rf_sig = inspect.signature(RandomForestClassifier)
    perm_sig = inspect.signature(permutation_importance)
    glm_fit_sig = inspect.signature(sm.GLM.fit)
    for required in TREE_PARAMS:
        if required not in dt_sig.parameters:
            errors.append(f"DecisionTreeClassifier API missing parameter: {required}")
    for required in FOREST_PARAMS:
        if required not in rf_sig.parameters:
            errors.append(f"RandomForestClassifier API missing parameter: {required}")
    for required in ["scoring", "n_repeats", "n_jobs", "random_state"]:
        if required not in perm_sig.parameters:
            errors.append(f"permutation_importance API missing parameter: {required}")
    for required in ["method", "maxiter", "tol", "cov_type"]:
        if required not in glm_fit_sig.parameters:
            errors.append(f"statsmodels GLM.fit API missing parameter: {required}")

    if errors:
        for msg in errors:
            append_event(events, "environment_verification", category="MandatoryEnvironmentFailure", message=msg, action="Stop before fitting")
        raise RuntimeError("; ".join(errors))

    return {
        "phase4a_audit_decision": PASS_DECISION,
        "canonical_preregistration_filename": CANONICAL_PREREG_FILENAME,
        "canonical_preregistration_expected_sha256": CANONICAL_PREREG_SHA256,
        "python_executable": sys.executable,
        "python_version": observed["python"],
        "packages": observed,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "working_directory": str(Path.cwd()),
        "phase4_working_directory": str(WORKDIR),
        "matplotlib_backend": matplotlib.get_backend(),
        "environment_controls_observed": observed_env,
        "environment_control_note": (
            "PYTHONHASHSEED and thread controls were established by the shell before the Python interpreter started. "
            "The script records observed values and does not claim that post-startup assignment would retroactively control the process."
        ),
        "api_checks": {
            "DecisionTreeClassifier_parameters": sorted(TREE_PARAMS),
            "RandomForestClassifier_parameters": sorted(FOREST_PARAMS),
            "permutation_importance_parameters_checked": ["scoring", "n_repeats", "n_jobs", "random_state"],
            "GLM_fit_parameters_checked": ["method", "maxiter", "tol", "cov_type"],
        },
        "run_started": RUN_STARTED,
    }


def build_initial_readme() -> str:
    return f"""# Phase 4B Modelling Working Files

**Phase 4A audit decision:** {PASS_DECISION}  
**Sole implementation authority:** `{CANONICAL_PREREG_FILENAME}`  
**Canonical expected SHA-256:** `{CANONICAL_PREREG_SHA256}`  
**Current status:** Execution in progress; no output is authoritative until the run completes and the manifest is finalised.

The target `Classes` is an FWI/FFMC-derived designation. This work evaluates label reproduction, not independently observed wildfire incidence, wildfire forecasting, or real-fire detection.
"""


def build_final_readme(preferred: dict[str, Any], manifest_note: str) -> str:
    decision = preferred.get("final_decision", "UNAVAILABLE")
    return f"""# Phase 4B — Modelling and Evaluation Working Package

## Authority and audit gate

**Phase 4A audit decision:** {PASS_DECISION}  
**Sole canonical implementation authority:** `{CANONICAL_PREREG_FILENAME}`  
**Canonical expected SHA-256:** `{CANONICAL_PREREG_SHA256}`  
**Phase 4B execution status:** Complete under the passed pre-registration; outputs await independent computational audit.

No frozen Phase 1–3 file was modified or regenerated.

## Interpretation boundary

`Classes` is an FWI/FFMC-derived class designation, not independently observed wildfire incidence. The exact class thresholds are undocumented. RQ1 reports out-of-month label-reproduction performance using Temperature, RH, Ws and Rain. Results must not be described as wildfire forecasting or real-fire detection.

## Preferred-model decision

`{decision}`

This decision uses only the unweighted mean four-fold primary balanced accuracy, the fixed 0.005 practical-tie rule, fold balanced-accuracy SD, and the fixed interpretability order. Sensitivity analyses are excluded from selection.

## Run command

The script must be launched from a shell that establishes the required process environment before Python starts:

```bash
PYTHONHASHSEED=140 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \\
MPLCONFIGDIR=04_Phase_4_Modelling_Working/.mplconfig \\
python3 04_Phase_4_Modelling_Working/phase4b_modelling.py \\
  --input Algerian_forest_fires_dataset_CLEANED.csv \\
  --manifest MASTER_MANIFEST.csv \\
  --root <directory-containing-uploaded-inputs> \\
  --workdir 04_Phase_4_Modelling_Working
```

## Principal outputs

- `fold_assignments.csv`, `oof_predictions.csv`, `fold_metrics.csv`, `metric_summary.csv`, `pooled_oof_metrics.csv`
- `model_selection_decision.json`
- `logistic_full_data_coefficients.csv`
- `permutation_importance_by_fold.csv`, `permutation_importance_summary.csv`
- `rq2_specification_results.csv`, `rq2_interaction_sensitivity.csv`
- `fig_4_rq1_lomo_balanced_accuracy.png`, `fig_5_rq1_logistic_odds_ratios.png`
- `PHASE4B_MANIFEST.csv`, `PHASE4B_RUN_LOG.txt`

## RQ2 and RQ3

RQ2 is a full-data logistic specification-sensitivity analysis with ordinary model-based intervals; it is not cross-validated and is not causal. RQ3 remains descriptive and uses the frozen Phase 3 Figures C and D. No Phase 3 figure was regenerated.

## Manifest/run-log finalisation

{manifest_note}

## Audit status

These files are working Phase 4B outputs. They are not frozen and must not be treated as final report authority until an independent computational audit passes them.
"""


def validate_hashes_and_inputs(root: Path, manifest_path: Path, data_path: Path, events: list[dict[str, Any]]) -> tuple[pd.DataFrame, pd.DataFrame]:
    manifest = pd.read_csv(manifest_path)
    required_manifest_cols = {"filename", "relative_path", "status", "sha256"}
    if not required_manifest_cols.issubset(manifest.columns):
        raise RuntimeError(f"MASTER_MANIFEST.csv missing columns: {sorted(required_manifest_cols - set(manifest.columns))}")

    prereg = root / CANONICAL_PREREG_FILENAME
    if prereg.name != CANONICAL_PREREG_FILENAME or not prereg.exists():
        raise RuntimeError(f"Canonical preregistration missing or incorrectly named: {prereg}")
    prereg_hash = sha256_file(prereg)
    if prereg_hash != CANONICAL_PREREG_SHA256:
        raise RuntimeError(f"Canonical preregistration SHA-256 mismatch: expected {CANONICAL_PREREG_SHA256}, observed {prereg_hash}")

    available_frozen = {
        "BDAV_Final_Assessment_Report__July_2026_docx-1.docx": root / "BDAV_F~1.DOC",
        "DAM140_Final_Assignment_Answer_Template-1.docx": root / "DAM140~1.DOC",
        "Grading_schema.pdf": root / "GRADIN~1.PDF",
        "Algerian_forest_fires_dataset_CLEANED.csv": data_path,
        "PHASE3_FROZEN_README.md": root / "PHASE3~1.MD",
        "PHASE3_FROZEN_SUMMARY.md": root / "PHASE3~2.MD",
        "phase3_frozen.py": root / "phase3_frozen.py",
        "BOOK_Chapter_Springer_ABID.pdf": root / "BOOK_Chapter_Springer_ABID.pdf",
    }

    rows: list[dict[str, Any]] = []
    for logical_name, actual_path in available_frozen.items():
        matches = manifest[manifest["filename"] == logical_name]
        if len(matches) != 1:
            raise RuntimeError(f"Manifest entry count for {logical_name} is {len(matches)}, expected 1")
        rec = matches.iloc[0]
        if "authoritative/frozen" not in str(rec["status"]):
            raise RuntimeError(f"Manifest status for {logical_name} is not authoritative/frozen: {rec['status']}")
        if not actual_path.exists():
            raise RuntimeError(f"Available frozen input missing: {actual_path}")
        observed = sha256_file(actual_path)
        expected = str(rec["sha256"])
        passed = observed == expected
        rows.append({
            "filename": logical_name,
            "logical_path": rec["relative_path"],
            "actual_path": str(actual_path),
            "input_type": "available_frozen_manifest_input",
            "expected_sha256": expected,
            "observed_sha256": observed,
            "verification_status": "PASS" if passed else "FAIL",
        })
        if not passed:
            raise RuntimeError(f"Frozen input hash mismatch for {logical_name}: expected {expected}, observed {observed}")

    if sha256_file(data_path) != INPUT_DATA_SHA256:
        raise RuntimeError("Cleaned CSV hash did not match the frozen preregistered value")
    if sha256_file(root / "PHASE3~2.MD") != PHASE3_SUMMARY_SHA256:
        raise RuntimeError("Phase 3 summary hash did not match the frozen preregistered value")
    if sha256_file(root / "phase3_frozen.py") != PHASE3_SCRIPT_SHA256:
        raise RuntimeError("Phase 3 script hash did not match the frozen preregistered value")

    working_inputs = [
        (CANONICAL_PREREG_FILENAME, prereg, CANONICAL_PREREG_SHA256, "canonical_phase4a_authority"),
        ("MASTER_MANIFEST.csv", manifest_path, "", "package_control"),
        ("RELEASE_NOTES.md", root / "RELEASE_NOTES.md", "", "package_control"),
        ("PHASE4_HANDOFF.md", root / "PHASE4_HANDOFF.md", "", "phase4_control"),
        ("ChatGPT_Phase4A_Audit.md.txt", root / "ChatGPT_Phase4A_Audit.md.txt", "", "phase4_audit_history"),
        ("Claude_Phase4A_Original.md.txt", root / "Claude_Phase4A_Original.md.txt", "", "phase4_audit_history"),
    ]
    for name, path, expected, input_type in working_inputs:
        if not path.exists():
            raise RuntimeError(f"Required controlling input missing: {path}")
        observed = sha256_file(path)
        passed = (observed == expected) if expected else True
        rows.append({
            "filename": name,
            "logical_path": name,
            "actual_path": str(path),
            "input_type": input_type,
            "expected_sha256": expected,
            "observed_sha256": observed,
            "verification_status": "PASS" if passed else "FAIL",
        })
        if not passed:
            raise RuntimeError(f"Controlling input hash mismatch for {name}: expected {expected}, observed {observed}")

    checks = pd.DataFrame(rows)

    df = pd.read_csv(data_path)
    if df.shape != (244, 17):
        raise RuntimeError(f"Dataset shape mismatch: expected (244, 17), observed {df.shape}")
    if list(df.columns) != REQUIRED_COLUMNS:
        raise RuntimeError(f"Dataset columns/order mismatch: expected {REQUIRED_COLUMNS}, observed {list(df.columns)}")
    if df[REQUIRED_COLUMNS].isna().any().any():
        missing = df[REQUIRED_COLUMNS].isna().sum()
        raise RuntimeError(f"Missing values detected: {missing[missing > 0].to_dict()}")
    if set(df["month"].unique()) != {6, 7, 8, 9}:
        raise RuntimeError(f"Month values mismatch: {sorted(df['month'].unique())}")
    if set(df["year"].unique()) != {2012}:
        raise RuntimeError(f"Year values mismatch: {sorted(df['year'].unique())}")
    if set(df["Region"].unique()) != {"Bejaia", "Sidi-Bel Abbes"}:
        raise RuntimeError(f"Region values mismatch: {sorted(df['Region'].unique())}")
    if set(df["Classes"].unique()) != {"not fire", "fire"}:
        raise RuntimeError(f"Class values mismatch: {sorted(df['Classes'].unique())}")
    if df.duplicated(["Region", "date"]).any():
        raise RuntimeError("Duplicate (Region, date) rows detected")

    parsed_date = pd.to_datetime(df["date"], format="%Y-%m-%d", errors="coerce")
    if parsed_date.isna().any():
        raise RuntimeError("Invalid date values detected")
    if not (parsed_date.dt.year.to_numpy() == df["year"].to_numpy()).all():
        raise RuntimeError("Date year and numeric year disagree")
    if not (parsed_date.dt.month.to_numpy() == df["month"].to_numpy()).all():
        raise RuntimeError("Date month and numeric month disagree")
    if not (parsed_date.dt.day.to_numpy() == df["day"].to_numpy()).all():
        raise RuntimeError("Date day and numeric day disagree")

    for feature in PRIMARY_FEATURES:
        numeric = pd.to_numeric(df[feature], errors="coerce")
        if numeric.isna().any() or not np.isfinite(numeric.to_numpy(dtype=float)).all():
            raise RuntimeError(f"Predictor {feature} is not finite numeric")
        df[feature] = numeric.astype(float)

    for fid, spec in FOLDS.items():
        counts = df.loc[df["month"] == spec["month"], "Classes"].value_counts()
        if set(counts.index) != {"not fire", "fire"}:
            raise RuntimeError(f"Held-out fold {fid} does not contain both classes: {counts.to_dict()}")

    df.insert(0, "source_row_id", np.arange(1, len(df) + 1, dtype=int))
    df["date"] = parsed_date
    df["target"] = df["Classes"].map(CLASS_TO_INT).astype(int)
    df["Rain_any"] = (df["Rain"] > 0.0).astype(int)
    return checks, df


def fit_glm(X_train: pd.DataFrame, y_train: pd.Series) -> Any:
    model = sm.GLM(y_train.astype(float), X_train.astype(float), family=sm.families.Binomial())
    result = model.fit(method="IRLS", maxiter=200, tol=1e-8, cov_type="nonrobust")
    if not bool(getattr(result, "converged", False)):
        raise RuntimeError("GLM did not report convergence")
    if not np.isfinite(np.asarray(result.params, dtype=float)).all():
        raise RuntimeError("GLM returned non-finite coefficients")
    return result


def check_probabilities(prob: np.ndarray) -> None:
    if prob.ndim != 1:
        raise RuntimeError(f"Predicted probability array must be one-dimensional, observed shape {prob.shape}")
    if not np.isfinite(prob).all():
        raise RuntimeError("Predicted probabilities contain non-finite values")
    if ((prob < 0.0) | (prob > 1.0)).any():
        raise RuntimeError("Predicted probabilities outside [0, 1]")


def metric_row(y_true: np.ndarray, y_pred: np.ndarray, prob: np.ndarray | None, baseline: bool, events: list[dict[str, Any]], variant: str, fold_id: str, model: str) -> dict[str, Any]:
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = [int(x) for x in cm.ravel()]
    if int(np.sum(y_pred == 1)) == 0:
        append_event(events, "metric_calculation", variant, fold_id, model, "UndefinedPositivePredictionCondition", "Model predicted no positive cases; precision and F1 use zero_division=0", "Recorded; no model change")
    result = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "fire_precision": float(precision_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "fire_recall": float(recall_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "fire_f1": float(f1_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "not_fire_recall": float(recall_score(y_true, y_pred, pos_label=0, zero_division=0)),
        "roc_auc": np.nan,
        "average_precision": np.nan,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "tp": tp,
    }
    if not baseline:
        if prob is None:
            raise RuntimeError("Probability scores required for non-baseline metrics")
        result["roc_auc"] = float(roc_auc_score(y_true, prob))
        result["average_precision"] = float(average_precision_score(y_true, prob))
    return result


def prediction_rows(df_test: pd.DataFrame, variant: str, fold_id: str, model: str, y_pred: np.ndarray | None, prob: np.ndarray | None, status: str, failure_message: str = "") -> list[dict[str, Any]]:
    rows = []
    for idx, (_, rec) in enumerate(df_test.iterrows()):
        pred_int = None if y_pred is None else int(y_pred[idx])
        pred_cls = "" if pred_int is None else INT_TO_CLASS[pred_int]
        p = np.nan if prob is None else float(prob[idx])
        rows.append({
            "variant": variant,
            "fold_id": fold_id,
            "held_out_month": int(rec["month"]),
            "source_row_id": int(rec["source_row_id"]),
            "date": rec["date"].date().isoformat(),
            "Region": rec["Region"],
            "true_label": int(rec["target"]),
            "true_class": rec["Classes"],
            "model": model,
            "predicted_label": pred_int,
            "predicted_class": pred_cls,
            "predicted_probability_fire": p,
            "threshold": THRESHOLD if model != MODEL_NAMES["baseline"] else np.nan,
            "status": status,
            "failure_message": failure_message,
        })
    return rows


def run_variant_fold(df: pd.DataFrame, variant: str, fold_id: str, use_gap: bool, run_models: list[str], events: list[dict[str, Any]], baseline_rows: list[dict[str, Any]], prep_rows: list[dict[str, Any]], pred_rows: list[dict[str, Any]], metric_rows: list[dict[str, Any]], primary_rf_store: dict[str, Any]) -> None:
    month = FOLDS[fold_id]["month"]
    test_mask = df["month"] == month
    train_mask = ~test_mask
    if use_gap:
        gap_ts = pd.to_datetime(GAP_DATES[fold_id])
        train_mask = train_mask & ~df["date"].isin(gap_ts)
    train = df.loc[train_mask].copy()
    test = df.loc[test_mask].copy()
    y_train = train["target"].to_numpy(dtype=int)
    y_test = test["target"].to_numpy(dtype=int)
    if set(np.unique(y_train)) != {0, 1}:
        raise RuntimeError(f"Training fold {variant}/{fold_id} lacks both classes")
    if set(np.unique(y_test)) != {0, 1}:
        raise RuntimeError(f"Test fold {variant}/{fold_id} lacks both classes")

    if "baseline" in run_models:
        fire_count = int(np.sum(y_train == 1))
        not_count = int(np.sum(y_train == 0))
        majority_label = 1 if fire_count > not_count else 0
        prevalence = fire_count / len(y_train)
        y_pred = np.full(len(test), majority_label, dtype=int)
        prob = np.full(len(test), prevalence, dtype=float)
        baseline_rows.append({
            "variant": variant,
            "fold_id": fold_id,
            "held_out_month": month,
            "training_row_count": len(train),
            "training_fire_count": fire_count,
            "training_not_fire_count": not_count,
            "training_fire_prevalence": prevalence,
            "majority_tie_rule": "not fire",
            "selected_majority_label": majority_label,
            "selected_majority_class": INT_TO_CLASS[majority_label],
            "class_generation_rule": "Training counts with not-fire tie; stored prevalence is not thresholded to generate class",
        })
        pred_rows.extend(prediction_rows(test, variant, fold_id, MODEL_NAMES["baseline"], y_pred, prob, "success"))
        met = metric_row(y_test, y_pred, prob, True, events, variant, fold_id, MODEL_NAMES["baseline"])
        metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": MODEL_NAMES["baseline"], "n_train": len(train), "n_test": len(test), "status": "success", "failure_message": "", **met})

    if "logistic" in run_models:
        model_name = MODEL_NAMES["logistic"]
        try:
            scaler = StandardScaler(with_mean=True, with_std=True, copy=True)
            X_train_arr = scaler.fit_transform(train[PRIMARY_FEATURES])
            if np.any(np.asarray(scaler.scale_) == 0.0):
                raise RuntimeError("Zero training-fold scale detected")
            X_test_arr = scaler.transform(test[PRIMARY_FEATURES])
            for feature, mean, scale in zip(PRIMARY_FEATURES, scaler.mean_, scaler.scale_):
                prep_rows.append({"variant": variant, "fold_id": fold_id, "model": model_name, "feature": feature, "training_mean": float(mean), "training_scale": float(scale), "transformation": "StandardScaler ddof=0; fit on permitted training rows"})
            X_train = pd.DataFrame(X_train_arr, columns=[f"{x}_z" for x in PRIMARY_FEATURES], index=train.index)
            X_test = pd.DataFrame(X_test_arr, columns=[f"{x}_z" for x in PRIMARY_FEATURES], index=test.index)
            X_train.insert(0, "const", 1.0)
            X_test.insert(0, "const", 1.0)
            result = capture_warnings(events, "model_fit", variant, fold_id, model_name, lambda: fit_glm(X_train, train["target"]))
            prob = np.asarray(result.predict(X_test), dtype=float)
            check_probabilities(prob)
            y_pred = (prob >= THRESHOLD).astype(int)
            pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, y_pred, prob, "success"))
            met = metric_row(y_test, y_pred, prob, False, events, variant, fold_id, model_name)
            metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "success", "failure_message": "", **met})
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"
            append_event(events, "model_fit", variant, fold_id, model_name, "ModelFitFailure", msg, "No retry; parameters unchanged")
            pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, None, None, "failed", msg))
            metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "failed", "failure_message": msg, **{k: np.nan for k in ["accuracy", "balanced_accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision", "tn", "fp", "fn", "tp"]}})

    if "tree" in run_models:
        model_name = MODEL_NAMES["tree"]
        try:
            estimator = DecisionTreeClassifier(**TREE_PARAMS)
            estimator = capture_warnings(events, "model_fit", variant, fold_id, model_name, lambda: estimator.fit(train[PRIMARY_FEATURES], y_train))
            if set(estimator.classes_) != {0, 1}:
                raise RuntimeError(f"Fitted classes are {estimator.classes_.tolist()}, expected [0, 1]")
            pos_idx = int(np.where(estimator.classes_ == 1)[0][0])
            prob = np.asarray(estimator.predict_proba(test[PRIMARY_FEATURES])[:, pos_idx], dtype=float)
            check_probabilities(prob)
            y_pred = (prob >= THRESHOLD).astype(int)
            pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, y_pred, prob, "success"))
            met = metric_row(y_test, y_pred, prob, False, events, variant, fold_id, model_name)
            metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "success", "failure_message": "", **met})
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"
            append_event(events, "model_fit", variant, fold_id, model_name, "ModelFitFailure", msg, "No retry; parameters unchanged")
            pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, None, None, "failed", msg))
            metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "failed", "failure_message": msg, **{k: np.nan for k in ["accuracy", "balanced_accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision", "tn", "fp", "fn", "tp"]}})

    if "forest" in run_models:
        model_name = MODEL_NAMES["forest"]
        try:
            estimator = RandomForestClassifier(**FOREST_PARAMS)
            estimator = capture_warnings(events, "model_fit", variant, fold_id, model_name, lambda: estimator.fit(train[PRIMARY_FEATURES], y_train))
            if set(estimator.classes_) != {0, 1}:
                raise RuntimeError(f"Fitted classes are {estimator.classes_.tolist()}, expected [0, 1]")
            pos_idx = int(np.where(estimator.classes_ == 1)[0][0])
            prob = np.asarray(estimator.predict_proba(test[PRIMARY_FEATURES])[:, pos_idx], dtype=float)
            check_probabilities(prob)
            y_pred = (prob >= THRESHOLD).astype(int)
            pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, y_pred, prob, "success"))
            met = metric_row(y_test, y_pred, prob, False, events, variant, fold_id, model_name)
            metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "success", "failure_message": "", **met})
            if variant == "primary":
                primary_rf_store[fold_id] = {"estimator": estimator, "X_test": test[PRIMARY_FEATURES].copy(), "y_test": y_test.copy()}
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"
            append_event(events, "model_fit", variant, fold_id, model_name, "ModelFitFailure", msg, "No retry; parameters unchanged")
            pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, None, None, "failed", msg))
            metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "failed", "failure_message": msg, **{k: np.nan for k in ["accuracy", "balanced_accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision", "tn", "fp", "fn", "tp"]}})


def run_rain_any_fold(df: pd.DataFrame, fold_id: str, events: list[dict[str, Any]], prep_rows: list[dict[str, Any]], pred_rows: list[dict[str, Any]], metric_rows: list[dict[str, Any]]) -> None:
    variant = "rain_any_sensitivity"
    model_name = MODEL_NAMES["rain_any"]
    month = FOLDS[fold_id]["month"]
    train = df.loc[df["month"] != month].copy()
    test = df.loc[df["month"] == month].copy()
    try:
        scaler = StandardScaler(with_mean=True, with_std=True, copy=True)
        X_train_cont = scaler.fit_transform(train[["Temperature", "RH", "Ws"]])
        if np.any(np.asarray(scaler.scale_) == 0.0):
            raise RuntimeError("Zero training-fold scale detected")
        X_test_cont = scaler.transform(test[["Temperature", "RH", "Ws"]])
        for feature, mean, scale in zip(["Temperature", "RH", "Ws"], scaler.mean_, scaler.scale_):
            prep_rows.append({"variant": variant, "fold_id": fold_id, "model": model_name, "feature": feature, "training_mean": float(mean), "training_scale": float(scale), "transformation": "StandardScaler ddof=0; fit on outer training rows"})
        prep_rows.append({"variant": variant, "fold_id": fold_id, "model": model_name, "feature": "Rain_any", "training_mean": np.nan, "training_scale": np.nan, "transformation": "Passed unchanged as deterministic 0/1 indicator"})
        X_train = pd.DataFrame(X_train_cont, columns=["Temperature_z", "RH_z", "Ws_z"], index=train.index)
        X_test = pd.DataFrame(X_test_cont, columns=["Temperature_z", "RH_z", "Ws_z"], index=test.index)
        X_train["Rain_any"] = train["Rain_any"].astype(float)
        X_test["Rain_any"] = test["Rain_any"].astype(float)
        X_train.insert(0, "const", 1.0)
        X_test.insert(0, "const", 1.0)
        result = capture_warnings(events, "model_fit", variant, fold_id, model_name, lambda: fit_glm(X_train, train["target"]))
        prob = np.asarray(result.predict(X_test), dtype=float)
        check_probabilities(prob)
        y_pred = (prob >= THRESHOLD).astype(int)
        pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, y_pred, prob, "success"))
        met = metric_row(test["target"].to_numpy(dtype=int), y_pred, prob, False, events, variant, fold_id, model_name)
        metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "success", "failure_message": "", **met})
    except Exception as exc:
        msg = f"{type(exc).__name__}: {exc}"
        append_event(events, "model_fit", variant, fold_id, model_name, "ModelFitFailure", msg, "No retry; sensitivity remains separate")
        pred_rows.extend(prediction_rows(test, variant, fold_id, model_name, None, None, "failed", msg))
        metric_rows.append({"variant": variant, "fold_id": fold_id, "held_out_month": month, "model": model_name, "n_train": len(train), "n_test": len(test), "status": "failed", "failure_message": msg, **{k: np.nan for k in ["accuracy", "balanced_accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision", "tn", "fp", "fn", "tp"]}})


def create_fold_assignments(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for fold_id, spec in FOLDS.items():
        test_month = spec["month"]
        gap_dates = set(GAP_DATES[fold_id])
        for _, rec in df.iterrows():
            date_str = rec["date"].date().isoformat()
            primary_role = "test" if int(rec["month"]) == test_month else "train"
            if primary_role == "test":
                gap_role = "test"
            elif date_str in gap_dates:
                gap_role = "excluded_gap"
            else:
                gap_role = "train"
            rows.append({
                "source_row_id": int(rec["source_row_id"]),
                "date": date_str,
                "Region": rec["Region"],
                "Classes": rec["Classes"],
                "fold_id": fold_id,
                "held_out_month": test_month,
                "primary_role": primary_role,
                "gap_role": gap_role,
            })
    return pd.DataFrame(rows)


def aggregate_metrics(fold_df: pd.DataFrame, pred_df: pd.DataFrame, events: list[dict[str, Any]]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    metric_cols = ["accuracy", "balanced_accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision"]
    summary_rows = []
    for (variant, model), group in fold_df.groupby(["variant", "model"], sort=False):
        for metric in metric_cols:
            vals = pd.to_numeric(group[metric], errors="coerce")
            finite = vals[np.isfinite(vals)]
            complete = len(finite) == 4
            summary_rows.append({
                "variant": variant,
                "model": model,
                "metric": metric,
                "fold_mean": float(finite.mean()) if complete else np.nan,
                "fold_sample_sd": float(finite.std(ddof=1)) if complete else np.nan,
                "finite_fold_count": int(len(finite)),
                "required_fold_count": 4,
                "summary_status": "complete" if complete else ("not_applicable_constant_baseline" if model == MODEL_NAMES["baseline"] and metric in {"roc_auc", "average_precision"} else "incomplete"),
            })
    summary = pd.DataFrame(summary_rows)

    pooled_rows = []
    cm_rows = []
    for (variant, model), group in pred_df.groupby(["variant", "model"], sort=False):
        success = group["status"].eq("success").all() and len(group) == 244
        if not success:
            for metric in metric_cols:
                pooled_rows.append({"variant": variant, "model": model, "metric": metric, "pooled_oof_value": np.nan, "source_row_count": len(group), "status": "incomplete"})
            continue
        y_true = group["true_label"].to_numpy(dtype=int)
        y_pred = group["predicted_label"].to_numpy(dtype=int)
        prob = group["predicted_probability_fire"].to_numpy(dtype=float)
        baseline = model == MODEL_NAMES["baseline"]
        met = metric_row(y_true, y_pred, prob, baseline, events, variant, "POOLED", model)
        for metric in metric_cols:
            pooled_rows.append({"variant": variant, "model": model, "metric": metric, "pooled_oof_value": met[metric], "source_row_count": len(group), "status": "complete" if np.isfinite(met[metric]) else "not_applicable_constant_baseline"})
        cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
        for actual_idx, actual in enumerate(["not fire", "fire"]):
            for pred_idx, predicted in enumerate(["not fire", "fire"]):
                cm_rows.append({"variant": variant, "model": model, "actual_class": actual, "predicted_class": predicted, "count": int(cm[actual_idx, pred_idx])})
    return summary, pd.DataFrame(pooled_rows), pd.DataFrame(cm_rows)


def sensitivity_export(variant: str, fold_df: pd.DataFrame, summary_df: pd.DataFrame, pooled_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    sub_fold = fold_df[fold_df["variant"] == variant]
    metric_cols = ["accuracy", "balanced_accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision"]
    for _, rec in sub_fold.iterrows():
        for metric in metric_cols:
            rows.append({"result_scope": "fold", "variant": variant, "model": rec["model"], "fold_id": rec["fold_id"], "metric": metric, "value": rec[metric], "sample_sd": np.nan, "source_row_count": rec["n_test"], "status": rec["status"]})
    for _, rec in summary_df[summary_df["variant"] == variant].iterrows():
        rows.append({"result_scope": "four_fold_summary", "variant": variant, "model": rec["model"], "fold_id": "", "metric": rec["metric"], "value": rec["fold_mean"], "sample_sd": rec["fold_sample_sd"], "source_row_count": np.nan, "status": rec["summary_status"]})
    for _, rec in pooled_df[pooled_df["variant"] == variant].iterrows():
        rows.append({"result_scope": "pooled_oof", "variant": variant, "model": rec["model"], "fold_id": "", "metric": rec["metric"], "value": rec["pooled_oof_value"], "sample_sd": np.nan, "source_row_count": rec["source_row_count"], "status": rec["status"]})
    return pd.DataFrame(rows)


def select_model(summary_df: pd.DataFrame, fold_df: pd.DataFrame, pred_df: pd.DataFrame) -> dict[str, Any]:
    primary_summary = summary_df[(summary_df["variant"] == "primary") & (summary_df["metric"] == "balanced_accuracy")]
    mean_map = dict(zip(primary_summary["model"], primary_summary["fold_mean"]))
    sd_map = dict(zip(primary_summary["model"], primary_summary["fold_sample_sd"]))
    baseline_mean = float(mean_map[MODEL_NAMES["baseline"]])
    candidates = [MODEL_NAMES["logistic"], MODEL_NAMES["tree"], MODEL_NAMES["forest"]]
    eligibility = {}
    for model in candidates:
        f = fold_df[(fold_df["variant"] == "primary") & (fold_df["model"] == model)]
        p = pred_df[(pred_df["variant"] == "primary") & (pred_df["model"] == model)]
        eligible = (
            len(f) == 4
            and f["status"].eq("success").all()
            and np.isfinite(f["balanced_accuracy"].to_numpy(dtype=float)).all()
            and len(p) == 244
            and p["status"].eq("success").all()
            and p["predicted_class"].ne("").all()
            and np.isfinite(p["predicted_probability_fire"].to_numpy(dtype=float)).all()
            and ((p["predicted_probability_fire"].to_numpy(dtype=float) >= 0.0) & (p["predicted_probability_fire"].to_numpy(dtype=float) <= 1.0)).all()
        )
        eligibility[model] = bool(eligible)
    exceeding = [m for m in candidates if eligibility[m] and float(mean_map[m]) > baseline_mean]
    result: dict[str, Any] = {
        "selection_metric": "unweighted mean four-fold primary balanced accuracy",
        "baseline_model": MODEL_NAMES["baseline"],
        "baseline_mean_balanced_accuracy": baseline_mean,
        "candidate_eligibility": eligibility,
        "candidate_mean_balanced_accuracy": {m: float(mean_map[m]) if np.isfinite(mean_map[m]) else None for m in candidates},
        "candidate_fold_balanced_accuracy_sample_sd": {m: float(sd_map[m]) if np.isfinite(sd_map[m]) else None for m in candidates},
        "candidates_strictly_exceeding_baseline": exceeding,
        "practical_tie_absolute_difference": 0.005,
        "sd_tie_absolute_difference": 0.005,
        "interpretability_order": candidates,
        "sensitivities_excluded": ["rain_any_sensitivity", "boundary_gap_sensitivity"],
    }
    if not exceeding:
        result.update({"maximum_candidate_mean_balanced_accuracy": None, "practical_tie_set": [], "sd_tie_set": [], "final_decision": "NO_CANDIDATE_EXCEEDED_FOLD_TRAINED_BASELINE", "decision_reason": "No eligible candidate had mean primary balanced accuracy strictly above the fold-trained baseline."})
        return result
    max_mean = max(float(mean_map[m]) for m in exceeding)
    practical = [m for m in exceeding if abs(float(mean_map[m]) - max_mean) <= 0.005]
    min_sd = min(float(sd_map[m]) for m in practical)
    sd_tie = [m for m in practical if abs(float(sd_map[m]) - min_sd) <= 0.005]
    chosen = next(m for m in candidates if m in sd_tie)
    result.update({
        "maximum_candidate_mean_balanced_accuracy": max_mean,
        "practical_tie_set": practical,
        "minimum_sd_within_practical_tie_set": min_sd,
        "sd_tie_set": sd_tie,
        "final_decision": chosen,
        "decision_reason": "Applied primary mean balanced accuracy, 0.005 practical tie, fold-SD comparison, then fixed interpretability order.",
    })
    return result


def full_data_logistic(df: pd.DataFrame, events: list[dict[str, Any]], prep_rows: list[dict[str, Any]]) -> pd.DataFrame:
    variant = "full_data_feature_contribution"
    model_name = MODEL_NAMES["logistic"]
    scaler = StandardScaler(with_mean=True, with_std=True, copy=True)
    X_arr = scaler.fit_transform(df[PRIMARY_FEATURES])
    if np.any(np.asarray(scaler.scale_) == 0.0):
        raise RuntimeError("Zero full-data scale detected")
    for feature, mean, scale in zip(PRIMARY_FEATURES, scaler.mean_, scaler.scale_):
        prep_rows.append({"variant": variant, "fold_id": "FULL_DATA", "model": model_name, "feature": feature, "training_mean": float(mean), "training_scale": float(scale), "transformation": "Full-data StandardScaler ddof=0 for post-validation descriptive refit"})
    X = pd.DataFrame(X_arr, columns=[f"{x}_z" for x in PRIMARY_FEATURES], index=df.index)
    X.insert(0, "const", 1.0)
    result = capture_warnings(events, "feature_contribution_fit", variant, "FULL_DATA", model_name, lambda: fit_glm(X, df["target"]))
    zcrit = 1.959963984540054
    rows = []
    for term in X.columns:
        beta = float(result.params[term])
        se = float(result.bse[term])
        low = beta - zcrit * se
        high = beta + zcrit * se
        base_feature = term.removesuffix("_z") if term != "const" else "intercept"
        if term == "const":
            mean = np.nan
            scale = np.nan
            interpretation = "Intercept; excluded from report figure"
        else:
            idx = PRIMARY_FEATURES.index(base_feature)
            mean = float(scaler.mean_[idx])
            scale = float(scaler.scale_[idx])
            interpretation = "Odds ratio per one full-data population-standard-deviation increase"
        rows.append({
            "term": term,
            "feature": base_feature,
            "full_data_mean": mean,
            "full_data_scale_ddof0": scale,
            "coefficient_beta": beta,
            "standard_error": se,
            "wald_z": float(result.tvalues[term]),
            "two_sided_model_based_p_value": float(result.pvalues[term]),
            "odds_ratio": math.exp(beta),
            "beta_ci95_low": low,
            "beta_ci95_high": high,
            "odds_ratio_ci95_low": math.exp(low),
            "odds_ratio_ci95_high": math.exp(high),
            "interval_label": "ordinary model-based Wald interval; not adjusted for temporal dependence",
            "interpretation_unit": interpretation,
            "converged": bool(result.converged),
        })
    return pd.DataFrame(rows)


def permutation_outputs(primary_rf_store: dict[str, Any], events: list[dict[str, Any]]) -> tuple[pd.DataFrame, pd.DataFrame]:
    repeat_rows = []
    fold_summary_rows = []
    all_success = all(fid in primary_rf_store for fid in FOLDS)
    if not all_success:
        append_event(events, "permutation_importance", category="PermutationImportanceFailure", message="One or more primary random-forest folds unavailable", action="No training-set substitute; cross-fold summary missing")
        return pd.DataFrame(columns=["fold_id", "feature", "repeat", "seed", "baseline_balanced_accuracy", "permuted_balanced_accuracy", "balanced_accuracy_decrease"]), pd.DataFrame(columns=["summary_level", "fold_id", "feature", "mean_importance", "sample_sd_importance", "repeat_count", "fold_count", "status"])
    for fid in FOLDS:
        stored = primary_rf_store[fid]
        est = stored["estimator"]
        X_test = stored["X_test"]
        y_test = stored["y_test"]
        baseline_ba = float(balanced_accuracy_score(y_test, est.predict(X_test)))
        seed = PERMUTATION_SEEDS[fid]
        result = capture_warnings(
            events,
            "permutation_importance",
            "primary",
            fid,
            MODEL_NAMES["forest"],
            lambda est=est, X_test=X_test, y_test=y_test, seed=seed: permutation_importance(
                est,
                X_test,
                y_test,
                scoring="balanced_accuracy",
                n_repeats=30,
                n_jobs=1,
                random_state=seed,
            ),
        )
        for j, feature in enumerate(PRIMARY_FEATURES):
            vals = np.asarray(result.importances[j], dtype=float)
            for repeat_idx, importance in enumerate(vals, start=1):
                repeat_rows.append({
                    "fold_id": fid,
                    "held_out_month": FOLDS[fid]["month"],
                    "feature": feature,
                    "repeat": repeat_idx,
                    "seed": seed,
                    "baseline_balanced_accuracy": baseline_ba,
                    "permuted_balanced_accuracy": baseline_ba - float(importance),
                    "balanced_accuracy_decrease": float(importance),
                })
            fold_summary_rows.append({
                "summary_level": "within_fold_30_repeats",
                "fold_id": fid,
                "feature": feature,
                "mean_importance": float(vals.mean()),
                "sample_sd_importance": float(vals.std(ddof=1)),
                "repeat_count": 30,
                "fold_count": 1,
                "status": "complete",
            })
    fold_summary = pd.DataFrame(fold_summary_rows)
    across_rows = []
    for feature in PRIMARY_FEATURES:
        vals = fold_summary.loc[fold_summary["feature"] == feature, "mean_importance"].to_numpy(dtype=float)
        across_rows.append({
            "summary_level": "across_four_folds",
            "fold_id": "ALL",
            "feature": feature,
            "mean_importance": float(vals.mean()),
            "sample_sd_importance": float(vals.std(ddof=1)),
            "repeat_count": 30,
            "fold_count": 4,
            "status": "complete" if len(vals) == 4 and np.isfinite(vals).all() else "incomplete",
        })
    summary = pd.concat([fold_summary, pd.DataFrame(across_rows)], ignore_index=True)
    return pd.DataFrame(repeat_rows), summary


def rq2_outputs(df: pd.DataFrame, events: list[dict[str, Any]]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    means = {f: float(df[f].mean()) for f in PRIMARY_FEATURES}
    centering = pd.DataFrame([{"feature": f, "full_data_arithmetic_mean": means[f], "centering_rule": f"{f}_c = {f} - mean({f})"} for f in PRIMARY_FEATURES])
    work = pd.DataFrame(index=df.index)
    work["const"] = 1.0
    work["region_sidi"] = (df["Region"] == "Sidi-Bel Abbes").astype(int)
    for f in PRIMARY_FEATURES:
        work[f"{f}_c"] = df[f] - means[f]
    work["region_sidi_x_Rain_c"] = work["region_sidi"] * work["Rain_c"]
    specs = {
        "R0_REGION_ONLY": ["const", "region_sidi"],
        "R1_REGION_TEMP_RH": ["const", "region_sidi", "Temperature_c", "RH_c"],
        "R2_REGION_ALL_WEATHER": ["const", "region_sidi", "Temperature_c", "RH_c", "Ws_c", "Rain_c"],
        "R3_REGION_RAIN_INTERACTION": ["const", "region_sidi", "Temperature_c", "RH_c", "Ws_c", "Rain_c", "region_sidi_x_Rain_c"],
    }
    results: dict[str, Any] = {}
    zcrit = 1.959963984540054
    primary_rows = []
    r3_row: dict[str, Any] = {}
    for spec_id, cols in specs.items():
        try:
            res = capture_warnings(events, "rq2_fit", "rq2_full_data", "FULL_DATA", spec_id, lambda cols=cols: fit_glm(work[cols], df["target"]))
            results[spec_id] = res
            beta = float(res.params["region_sidi"])
            se = float(res.bse["region_sidi"])
            low, high = beta - zcrit * se, beta + zcrit * se
            base = {
                "specification_id": spec_id,
                "status": "success",
                "failure_message": "",
                "design_columns": " + ".join(cols),
                "n_observations": int(res.nobs),
                "n_parameters": len(res.params),
                "converged": bool(res.converged),
                "log_likelihood": float(res.llf),
                "aic": float(res.aic),
                "region_coefficient": beta,
                "region_standard_error": se,
                "region_wald_z": float(res.tvalues["region_sidi"]),
                "region_two_sided_model_based_p_value": float(res.pvalues["region_sidi"]),
                "region_odds_ratio": math.exp(beta),
                "region_beta_ci95_low": low,
                "region_beta_ci95_high": high,
                "region_odds_ratio_ci95_low": math.exp(low),
                "region_odds_ratio_ci95_high": math.exp(high),
                "interval_label": "ordinary model-based Wald interval; not adjusted for temporal dependence",
            }
            if spec_id != "R3_REGION_RAIN_INTERACTION":
                primary_rows.append(base)
            else:
                ib = float(res.params["region_sidi_x_Rain_c"])
                ise = float(res.bse["region_sidi_x_Rain_c"])
                ilow, ihigh = ib - zcrit * ise, ib + zcrit * ise
                r3_row = {
                    **base,
                    "analysis_status": "exploratory sensitivity only",
                    "interaction_coefficient": ib,
                    "interaction_standard_error": ise,
                    "interaction_wald_z": float(res.tvalues["region_sidi_x_Rain_c"]),
                    "interaction_two_sided_model_based_p_value": float(res.pvalues["region_sidi_x_Rain_c"]),
                    "interaction_odds_ratio_per_1mm": math.exp(ib),
                    "interaction_beta_ci95_low": ilow,
                    "interaction_beta_ci95_high": ihigh,
                    "interaction_odds_ratio_ci95_low": math.exp(ilow),
                    "interaction_odds_ratio_ci95_high": math.exp(ihigh),
                }
        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}"
            append_event(events, "rq2_fit", "rq2_full_data", "FULL_DATA", spec_id, "RQ2FitFailure", msg, "No replacement specification")
            fail = {"specification_id": spec_id, "status": "failed", "failure_message": msg, "design_columns": " + ".join(cols), "n_observations": len(df), "n_parameters": len(cols), "converged": False}
            if spec_id != "R3_REGION_RAIN_INTERACTION":
                primary_rows.append(fail)
            else:
                r3_row = {**fail, "analysis_status": "exploratory sensitivity only"}
    lrt = {"lrt_reduced_model": "R2_REGION_ALL_WEATHER", "lrt_full_model": "R3_REGION_RAIN_INTERACTION", "lrt_df": 1, "lrt_alpha": 0.05, "lrt_status": "not_calculated", "lrt_statistic": np.nan, "lrt_p_value": np.nan, "lrt_interpretation": "Not calculated because one or both required models failed."}
    if "R2_REGION_ALL_WEATHER" in results and "R3_REGION_RAIN_INTERACTION" in results:
        d = 2.0 * (float(results["R3_REGION_RAIN_INTERACTION"].llf) - float(results["R2_REGION_ALL_WEATHER"].llf))
        if -1e-8 <= d < 0:
            append_event(events, "rq2_lrt", "rq2_full_data", "FULL_DATA", "R2_vs_R3", "NumericalTolerance", f"LRT statistic {d} set to zero", "Applied preregistered tolerance")
            d = 0.0
        if d < -1e-8:
            append_event(events, "rq2_lrt", "rq2_full_data", "FULL_DATA", "R2_vs_R3", "LRTFailure", f"Nested likelihood ordering inconsistent; statistic {d}", "LRT not calculated")
            lrt["lrt_status"] = "failed_negative_statistic"
            lrt["lrt_interpretation"] = "LRT failed because the nested-fit likelihood ordering was inconsistent."
        else:
            p = float(stats.chi2.sf(d, 1))
            lrt.update({
                "lrt_status": "complete",
                "lrt_statistic": d,
                "lrt_p_value": p,
                "lrt_interpretation": (
                    "Evidence that adding the exploratory Region × Rain term improves in-sample fit under the specified models."
                    if p < 0.05
                    else "Insufficient evidence that the exploratory Region × Rain term improves in-sample fit under the specified models."
                ),
            })
    r3_row.update(lrt)
    return centering, pd.DataFrame(primary_rows), pd.DataFrame([r3_row])


def generate_figures(workdir: Path) -> None:
    fold = pd.read_csv(workdir / "fold_metrics.csv")
    primary = fold[fold["variant"] == "primary"].copy()
    order = [MODEL_NAMES["baseline"], MODEL_NAMES["logistic"], MODEL_NAMES["tree"], MODEL_NAMES["forest"]]
    labels = {
        MODEL_NAMES["baseline"]: "Fold-trained baseline",
        MODEL_NAMES["logistic"]: "Logistic regression",
        MODEL_NAMES["tree"]: "Decision tree",
        MODEL_NAMES["forest"]: "Random forest",
    }
    x = np.arange(4)
    month_labels = [FOLDS[f]["name"] for f in FOLDS]
    fig, ax = plt.subplots(figsize=(9, 5.2))
    for model in order:
        sub = primary[primary["model"] == model].set_index("fold_id").reindex(FOLDS.keys())
        ax.plot(x, sub["balanced_accuracy"].to_numpy(dtype=float), marker="o", label=labels[model])
    ax.axhline(0.5, linestyle="--", linewidth=1, label="Balanced-accuracy reference (0.5)")
    ax.set_xticks(x)
    ax.set_xticklabels(month_labels)
    ax.set_ylim(0.0, 1.0)
    ax.set_xlabel("Held-out month")
    ax.set_ylabel("Balanced accuracy")
    ax.set_title("Out-of-month class-designation reproduction")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(workdir / "fig_4_rq1_lomo_balanced_accuracy.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    coef = pd.read_csv(workdir / "logistic_full_data_coefficients.csv")
    coef = coef[coef["feature"].isin(PRIMARY_FEATURES)].set_index("feature").reindex(PRIMARY_FEATURES).reset_index()
    y = np.arange(len(coef))
    or_values = coef["odds_ratio"].to_numpy(dtype=float)
    low = coef["odds_ratio_ci95_low"].to_numpy(dtype=float)
    high = coef["odds_ratio_ci95_high"].to_numpy(dtype=float)
    xerr = np.vstack([or_values - low, high - or_values])
    fig, ax = plt.subplots(figsize=(8.5, 5.4))
    ax.errorbar(or_values, y, xerr=xerr, fmt="o", capsize=4)
    ax.axvline(1.0, linestyle="--", linewidth=1)
    ax.set_xscale("log")
    ax.set_yticks(y)
    ax.set_yticklabels(["Temperature", "Relative humidity", "Wind speed", "Rain"])
    ax.invert_yaxis()
    ax.set_xlabel("Odds ratio per one standard-deviation increase (log scale)")
    ax.set_title("Primary logistic weather contributions to class designation")
    fig.text(0.5, 0.01, "Intervals are ordinary model-based intervals and are not adjusted for temporal dependence.\nThe target is an FWI/FFMC-derived designation.", ha="center", va="bottom", fontsize=9)
    fig.tight_layout(rect=[0, 0.08, 1, 1])
    fig.savefig(workdir / "fig_5_rq1_logistic_odds_ratios.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def build_manifest(workdir: Path) -> pd.DataFrame:
    excluded = {"PHASE4B_MANIFEST.csv", "PHASE4B_RUN_LOG.txt"}
    rows = []
    for path in sorted(p for p in workdir.rglob("*") if p.is_file()):
        rel = path.relative_to(workdir).as_posix()
        if rel in excluded:
            continue
        rows.append({
            "relative_path": rel,
            "purpose": OUTPUT_PURPOSES.get(rel, "Supporting Phase 4B runtime artefact"),
            "status": "complete",
            "file_size": path.stat().st_size,
            "sha256": sha256_file(path),
        })
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--root", required=True)
    parser.add_argument("--workdir", required=True)
    args = parser.parse_args()

    global WORKDIR, RUN_STARTED
    WORKDIR = Path(args.workdir).resolve()
    RUN_STARTED = iso_now()
    root = Path(args.root).resolve()
    data_path = Path(args.input).resolve()
    manifest_path = Path(args.manifest).resolve()
    WORKDIR.mkdir(parents=True, exist_ok=True)
    (WORKDIR / ".mplconfig").mkdir(parents=True, exist_ok=True)

    random.seed(MASTER_SEED)
    np.random.seed(MASTER_SEED)

    events: list[dict[str, Any]] = []
    log_lines = [
        "DAM140 PHASE 4B RUN LOG",
        f"Run started: {RUN_STARTED}",
        f"Phase 4A audit decision: {PASS_DECISION}",
        f"Sole canonical implementation authority: {CANONICAL_PREREG_FILENAME}",
        f"Expected canonical SHA-256: {CANONICAL_PREREG_SHA256}",
        "Interpretation: out-of-month reproduction of an FWI/FFMC-derived class designation; not wildfire forecasting or real-fire detection.",
    ]
    (WORKDIR / "PHASE4B_RUN_LOG.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")
    (WORKDIR / "PHASE4B_README.md").write_text(build_initial_readme(), encoding="utf-8")

    try:
        env_info = validate_environment(events)
        log_lines.append("Environment and API verification: PASS")
        checks, df = validate_hashes_and_inputs(root, manifest_path, data_path, events)
        log_lines.append("Canonical preregistration filename and SHA-256: PASS")
        log_lines.append("Available frozen-input hashes against MASTER_MANIFEST.csv: PASS")
        log_lines.append("Dataset schema, row count, labels, dates, regions and predictors: PASS")

        write_json(WORKDIR / "PHASE4B_ENVIRONMENT.json", env_info)
        requirements = """# Python 3.13.5\nnumpy==2.3.5\npandas==2.2.3\nscipy==1.17.0\nstatsmodels==0.14.6\nscikit-learn==1.8.0\nmatplotlib==3.10.8\n"""
        (WORKDIR / "PHASE4B_REQUIREMENTS.txt").write_text(requirements, encoding="utf-8")
        specification = {
            "authority": {"filename": CANONICAL_PREREG_FILENAME, "expected_sha256": CANONICAL_PREREG_SHA256, "audit_decision": PASS_DECISION},
            "target": {"column": "Classes", "mapping": CLASS_TO_INT, "positive_class": "fire", "probability_threshold": THRESHOLD, "provenance": "FWI/FFMC-derived designation; not independently observed wildfire incidence"},
            "primary_predictors": PRIMARY_FEATURES,
            "prohibited_principal_predictors": ["FWI", "FFMC", "DMC", "DC", "ISI", "BUI"],
            "rain_sensitivity": {"definition": "Rain_any = 1 if Rain > 0.0 else 0", "predictors": SENSITIVITY_FEATURES, "selection_excluded": True},
            "folds": FOLDS,
            "gap_dates": GAP_DATES,
            "baseline": {"majority_from_training_counts": True, "tie_class": "not fire", "stored_probability": "training fire prevalence; not thresholded to generate class", "roc_auc_and_average_precision": "not applicable"},
            "logistic": {"implementation": "statsmodels.api.GLM", "family": "Binomial", "link": "logit", "penalty": None, "fit_method": "IRLS", "maxiter": 200, "tol": 1e-8, "cov_type": "nonrobust", "scaler": {"with_mean": True, "with_std": True, "ddof": 0, "training_fold_only": True}},
            "decision_tree": TREE_PARAMS,
            "random_forest": FOREST_PARAMS,
            "metrics": {"primary": "balanced_accuracy", "secondary": ["accuracy", "fire_precision", "fire_recall", "fire_f1", "not_fire_recall", "roc_auc", "average_precision"], "fold_summary": "unweighted arithmetic mean and sample SD ddof=1", "pooled_oof": "separate"},
            "model_selection": {"eligible_models": [MODEL_NAMES["logistic"], MODEL_NAMES["tree"], MODEL_NAMES["forest"]], "baseline_excluded": True, "must_strictly_exceed_baseline": True, "practical_tie_absolute_difference": 0.005, "sd_tie_absolute_difference": 0.005, "interpretability_order": [MODEL_NAMES["logistic"], MODEL_NAMES["tree"], MODEL_NAMES["forest"]]},
            "permutation_importance": {"model": MODEL_NAMES["forest"], "held_out_only": True, "scoring": "balanced_accuracy", "n_repeats": 30, "seeds": PERMUTATION_SEEDS, "n_jobs": 1},
            "rq2": {"cross_validated": False, "centering": "full-data arithmetic means, no SD scaling", "specifications": ["R0_REGION_ONLY", "R1_REGION_TEMP_RH", "R2_REGION_ALL_WEATHER", "R3_REGION_RAIN_INTERACTION"], "R3_status": "exploratory sensitivity only", "lrt": {"reduced": "R2_REGION_ALL_WEATHER", "full": "R3_REGION_RAIN_INTERACTION", "df": 1, "alpha": 0.05}},
            "seeds": {"master": MASTER_SEED, "tree": 140, "forest": 140, "permutation": PERMUTATION_SEEDS},
            "environment_controls": THREAD_ENV,
            "excluded_analyses": ["random cross-validation", "hyperparameter tuning", "threshold optimisation", "calibration", "Brier score", "partial dependence"],
            "failure_rule": "No parameter changes, no retries with alternative estimators, failed primary fold makes candidate ineligible",
        }
        write_json(WORKDIR / "PHASE4B_MODEL_SPECIFICATION.json", specification)
        write_csv(WORKDIR / "input_checksums.csv", checks)

        fold_assignments = create_fold_assignments(df)
        write_csv(WORKDIR / "fold_assignments.csv", fold_assignments)

        baseline_rows: list[dict[str, Any]] = []
        prep_rows: list[dict[str, Any]] = []
        pred_rows: list[dict[str, Any]] = []
        fold_metric_rows: list[dict[str, Any]] = []
        primary_rf_store: dict[str, Any] = {}

        for fid in FOLDS:
            run_variant_fold(df, "primary", fid, False, ["baseline", "logistic", "tree", "forest"], events, baseline_rows, prep_rows, pred_rows, fold_metric_rows, primary_rf_store)
        log_lines.append("Primary four-fold LOMO execution: complete")

        for fid in FOLDS:
            run_rain_any_fold(df, fid, events, prep_rows, pred_rows, fold_metric_rows)
        log_lines.append("Rain_any logistic sensitivity: complete")

        for fid in FOLDS:
            run_variant_fold(df, "boundary_gap_sensitivity", fid, True, ["baseline", "logistic", "tree", "forest"], events, baseline_rows, prep_rows, pred_rows, fold_metric_rows, primary_rf_store)
        log_lines.append("Three-day boundary-gap sensitivity: complete")

        baseline_df = pd.DataFrame(baseline_rows)
        prep_df = pd.DataFrame(prep_rows)
        pred_df = pd.DataFrame(pred_rows)
        fold_df = pd.DataFrame(fold_metric_rows)

        summary_df, pooled_df, pooled_cm_df = aggregate_metrics(fold_df, pred_df, events)
        selection = select_model(summary_df, fold_df, pred_df)
        log_lines.append(f"Preferred-model decision: {selection['final_decision']}")

        logistic_coef_df = full_data_logistic(df, events, prep_rows)
        prep_df = pd.DataFrame(prep_rows)
        log_lines.append("Post-validation full-data logistic coefficient analysis: complete")

        perm_by_fold_df, perm_summary_df = permutation_outputs(primary_rf_store, events)
        log_lines.append("Held-out random-forest permutation importance: complete")

        rq2_center_df, rq2_primary_df, rq2_interaction_df = rq2_outputs(df, events)
        log_lines.append("RQ2 four-specification analysis and planned R2-versus-R3 LRT: complete")
        log_lines.append("RQ3: confirmed descriptive; no model and no Phase 3 figure regeneration")

        write_csv(WORKDIR / "baseline_training_counts.csv", baseline_df)
        write_csv(WORKDIR / "preprocessing_parameters.csv", prep_df)
        write_csv(WORKDIR / "oof_predictions.csv", pred_df)
        write_csv(WORKDIR / "fold_metrics.csv", fold_df)
        write_csv(WORKDIR / "metric_summary.csv", summary_df)
        write_csv(WORKDIR / "pooled_oof_metrics.csv", pooled_df)
        write_csv(WORKDIR / "pooled_confusion_matrices.csv", pooled_cm_df)
        write_json(WORKDIR / "model_selection_decision.json", selection)
        write_csv(WORKDIR / "rain_binary_sensitivity_metrics.csv", sensitivity_export("rain_any_sensitivity", fold_df, summary_df, pooled_df))
        write_csv(WORKDIR / "boundary_gap_sensitivity_metrics.csv", sensitivity_export("boundary_gap_sensitivity", fold_df, summary_df, pooled_df))
        write_csv(WORKDIR / "logistic_full_data_coefficients.csv", logistic_coef_df)
        write_csv(WORKDIR / "permutation_importance_by_fold.csv", perm_by_fold_df)
        write_csv(WORKDIR / "permutation_importance_summary.csv", perm_summary_df)
        write_csv(WORKDIR / "rq2_centering_values.csv", rq2_center_df)
        write_csv(WORKDIR / "rq2_specification_results.csv", rq2_primary_df)
        write_csv(WORKDIR / "rq2_interaction_sensitivity.csv", rq2_interaction_df)

        generate_figures(WORKDIR)
        log_lines.append("Approved Phase 4 Figures 4 and 5: generated from code outputs")

        # Finalise warnings before manifest. A zero-event file still has exact columns.
        event_cols = ["timestamp", "stage", "variant", "fold_id", "model", "category", "message", "action"]
        event_df = pd.DataFrame(events, columns=event_cols)
        write_csv(WORKDIR / "warnings_and_failures.csv", event_df)
        log_lines.append(f"Captured warning/failure records: {len(event_df)}")

        # Remove the runtime-only matplotlib cache before final artefact finalisation.
        mpl_dir = WORKDIR / ".mplconfig"
        if mpl_dir.exists():
            shutil.rmtree(mpl_dir)

        manifest_note = (
            "All numerical outputs, configuration files, CSV files, figures and documentation were finalised first. "
            "The main run-log content was then finalised without a manifest hash or final completion record. "
            "`PHASE4B_MANIFEST.csv` excludes itself and `PHASE4B_RUN_LOG.txt`. The completed manifest was hashed, "
            "and its filename, SHA-256, final status and completion timestamp were appended to the run log. "
            "The manifest was not altered after its hash was written. The run log is intentionally excluded because it is the final file written."
        )
        (WORKDIR / "PHASE4B_README.md").write_text(build_final_readme(selection, manifest_note), encoding="utf-8")

        # Complete and finalise main run-log content, without manifest hash/final completion record.
        log_lines.extend([
            "All numerical outputs, configuration files, CSV files, figures, documentation and other Phase 4B artefacts: finalised",
            "Main execution content finalised; PHASE4B_MANIFEST.csv generation pending",
            "Manifest exclusion rule: PHASE4B_MANIFEST.csv and PHASE4B_RUN_LOG.txt are excluded",
        ])
        (WORKDIR / "PHASE4B_RUN_LOG.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")

        # Generate, finalise and hash manifest. Do not alter it afterwards.
        manifest_df = build_manifest(WORKDIR)
        write_csv(WORKDIR / "PHASE4B_MANIFEST.csv", manifest_df)
        manifest_hash = sha256_file(WORKDIR / "PHASE4B_MANIFEST.csv")
        completion = iso_now()

        # The run log is intentionally the final file written.
        with (WORKDIR / "PHASE4B_RUN_LOG.txt").open("a", encoding="utf-8") as f:
            f.write(f"Manifest filename: PHASE4B_MANIFEST.csv\n")
            f.write(f"Manifest SHA-256: {manifest_hash}\n")
            f.write("Final run status: COMPLETE_SUCCESS\n")
            f.write(f"Final completion timestamp: {completion}\n")
            f.write("Run log exclusion rationale: final file written; contains the completed manifest hash.\n")
        return 0
    except Exception as exc:
        append_event(events, "fatal", category="FatalExecutionFailure", message=f"{type(exc).__name__}: {exc}", action="Stopped; no silent substitution")
        tb = traceback.format_exc()
        log_lines.extend([f"FATAL FAILURE: {type(exc).__name__}: {exc}", tb, f"Failure timestamp: {iso_now()}"])
        (WORKDIR / "PHASE4B_RUN_LOG.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")
        event_cols = ["timestamp", "stage", "variant", "fold_id", "model", "category", "message", "action"]
        write_csv(WORKDIR / "warnings_and_failures.csv", pd.DataFrame(events, columns=event_cols))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
