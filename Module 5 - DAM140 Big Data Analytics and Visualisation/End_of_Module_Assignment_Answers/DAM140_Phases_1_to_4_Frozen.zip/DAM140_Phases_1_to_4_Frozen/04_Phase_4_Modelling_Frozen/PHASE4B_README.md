# Phase 4B — Modelling and Evaluation Working Package

## Authority and audit gate

**Phase 4A audit decision:** PASS — Freeze Phase 4A and authorise Phase 4B  
**Sole canonical implementation authority:** `PHASE4A_REVISED_PREREGISTRATION.md`  
**Canonical expected SHA-256:** `13c6baf60706f49f8d450a74775849b36555a453ad881620653f638b0fb40d98`  
**Phase 4B execution status:** Complete under the passed pre-registration; outputs await independent computational audit.

No frozen Phase 1–3 file was modified or regenerated.

## Interpretation boundary

`Classes` is an FWI/FFMC-derived class designation, not independently observed wildfire incidence. The exact class thresholds are undocumented. RQ1 reports out-of-month label-reproduction performance using Temperature, RH, Ws and Rain. Results must not be described as wildfire forecasting or real-fire detection.

## Preferred-model decision

`random_forest`

This decision uses only the unweighted mean four-fold primary balanced accuracy, the fixed 0.005 practical-tie rule, fold balanced-accuracy SD, and the fixed interpretability order. Sensitivity analyses are excluded from selection.

## Run command

The script must be launched from a shell that establishes the required process environment before Python starts:

```bash
PYTHONHASHSEED=140 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
MPLCONFIGDIR=04_Phase_4_Modelling_Working/.mplconfig \
python3 04_Phase_4_Modelling_Working/phase4b_modelling.py \
  --input Algerian_forest_fires_dataset_CLEANED.csv \
  --manifest MASTER_MANIFEST.csv \
  --root <directory-containing-uploaded-inputs> \
  --workdir 04_Phase_4_Modelling_Working
```

## Principal outputs

- `fold_assignments.csv`, `oof_predictions.csv`, `fold_metrics.csv`, `metric_summary.csv`, `pooled_oof_metrics.csv`
- `model_selection_decision.json`
- `logistic_full_data_coefficients.csv`
- `permutation_importance_by_fold.csv`, `permutation_importance_summary.csv`
- `rq2_specification_results.csv`, `rq2_interaction_sensitivity.csv`
- `fig_4_rq1_lomo_balanced_accuracy.png`, `fig_5_rq1_logistic_odds_ratios.png`
- `PHASE4B_MANIFEST.csv`, `PHASE4B_RUN_LOG.txt`

## RQ2 and RQ3

RQ2 is a full-data logistic specification-sensitivity analysis with ordinary model-based intervals; it is not cross-validated and is not causal. RQ3 remains descriptive and uses the frozen Phase 3 Figures C and D. No Phase 3 figure was regenerated.

## Manifest/run-log finalisation

All numerical outputs, configuration files, CSV files, figures and documentation were finalised first. The main run-log content was then finalised without a manifest hash or final completion record. `PHASE4B_MANIFEST.csv` excludes itself and `PHASE4B_RUN_LOG.txt`. The completed manifest was hashed, and its filename, SHA-256, final status and completion timestamp were appended to the run log. The manifest was not altered after its hash was written. The run log is intentionally excluded because it is the final file written.

## Audit status

These files are working Phase 4B outputs. They are not frozen and must not be treated as final report authority until an independent computational audit passes them.
