# PHASE4B COMPUTATIONAL AUDIT

**Project:** DAM140 Big Data Analytics and Visualization Assessment  
**Auditor role:** `02_Phase4_Auditor`  
**Audit date:** 30 July 2026  
**Controlling implementation specification:** `PHASE4A_REVISED_PREREGISTRATION.md`  
**Canonical preregistration SHA-256:** `13c6baf60706f49f8d450a74775849b36555a453ad881620653f638b0fb40d98`  
**Audited implementation script SHA-256:** `068eafeba6c9e7175ff7866f17153204f3d1c6347e4e3e37db0648933c4ddf29`

## Executive Summary

The Phase 4B implementation is computationally reproducible and materially complies with the passed Phase 4A preregistration.

I independently executed the supplied `phase4b_modelling.py` in a clean working directory under the registered Python and package versions and the registered process controls. Every analytical CSV and JSON result was reproduced exactly or to floating-point precision. The regenerated Figures 4 and 5 had the exact sizes and SHA-256 values recorded in the supplied Phase 4B manifest. Differences were confined to timestamps, absolute paths, the audit-run input-control placeholders, and chat-platform image transcoding.

The implementation is leakage-safe: scaling is learned inside each training fold; the baseline class is learned from training counts; raw Rain remains primary; `Rain_any` is sensitivity-only; thresholds and model settings are fixed; and sensitivity results do not influence model selection.

The preregistered selection rule independently selects `random_forest`. The stronger `Rain_any` sensitivity was correctly excluded from selection.

The main caution is interpretive rather than computational. The full-data Rain coefficient is finite and reproducible but strongly influenced by one unusual fire-labelled record with 6.0 mm Rain. RQ2 model R3 also converges and is full-rank, but its enormous region and interaction odds ratios arise from sparse, near-separating rainfall patterns. R3 is valid as an exploratory sensitivity but is too unstable for detailed odds-ratio interpretation in the final report.

No analytical rerun or model correction is required. The eventual frozen package should exclude `__pycache__` and regenerate its manifest and run-log hash accordingly.

**Final gate decision: PASS WITH MINOR NON-BLOCKING CORRECTIONS.**

---

## Package and Integrity Verdict

### Package readability and completeness

The ZIP container itself was not mounted in the audit runtime. The extracted Phase 4B files were supplied individually and were readable. All preregistered output categories were present:

- implementation, specification, requirements and environment files;
- fold assignments, predictions and metrics;
- model-selection decision;
- both sensitivity outputs;
- coefficient and permutation-importance outputs;
- RQ2 outputs;
- Figures 4 and 5;
- README, run log and manifest.

The supplied manifest contains 27 entries. It contains every required manifest-included artefact plus one unnecessary runtime artefact:

`__pycache__/phase4b_modelling.cpython-313.pyc`

The run log and manifest are correctly excluded from the manifest itself.

### Manifest verification

The actual SHA-256 of `PHASE4B_MANIFEST.csv` is:

`44c3194a49a6e08cf5ea62f3ed06756e41af5aa48ee4c82d6228c01f9f1e6dc3`

This exactly matches the hash recorded in `PHASE4B_RUN_LOG.txt`.

All supplied non-image manifest entries matched their recorded sizes and SHA-256 values. The two PNG files mounted from the chat did not match because the chat platform had transcoded them. Independent regeneration produced the exact original package values:

| File | Manifest size | Manifest SHA-256 | Independent regeneration |
|---|---:|---|---|
| `fig_4_rq1_lomo_balanced_accuracy.png` | 177,979 | `2711a840931abbaa2ad119e9b8e28f2ef21911622b03c4e54f480cb9aa4f9908` | Exact match |
| `fig_5_rq1_logistic_odds_ratios.png` | 134,688 | `2c5dca9a6ef035278486b7cb1d657d983b42016bd426557a2b6020d05f28b1a6` | Exact match |

This demonstrates that the original package figures were code-generated and not manually altered.

### Input and frozen-file integrity

The supplied records verify:

- canonical preregistration hash: PASS;
- cleaned CSV hash: `9b24dd2ee6e5678ebb323ceb9b9e8d8f1d351df3974b80ca2ebf49d69a73da6a`;
- frozen Phase 3 summary and script hashes: PASS;
- assessment and reference files checked against the master manifest: PASS.

Static code inspection found no read from any superseded Phase 3 script or archived figure. All writes are directed to the Phase 4 working directory. The frozen CSV and frozen Phase 3 files are read or hashed only.

### `__pycache__`

`__pycache__` is not an analytical or reproducibility deliverable and should be excluded from the eventual frozen package. Removing it does not require model re-execution, but the release manifest and the manifest hash recorded in the run log must be regenerated after removal.

---

## Independent-Execution Verdict

### Environment

The audit environment exactly matched the preregistration:

- Python 3.13.5
- NumPy 2.3.5
- pandas 2.2.3
- SciPy 1.17.0
- statsmodels 0.14.6
- scikit-learn 1.8.0
- matplotlib 3.10.8

The execution used:

- `PYTHONHASHSEED=140`
- `OMP_NUM_THREADS=1`
- `MKL_NUM_THREADS=1`
- `OPENBLAS_NUM_THREADS=1`
- `NUMEXPR_NUM_THREADS=1`
- `MPLCONFIGDIR` inside the clean Phase 4 working directory.

### Reproduction comparison

The independent run reproduced byte-identically:

- `baseline_training_counts.csv`
- `boundary_gap_sensitivity_metrics.csv`
- `fold_assignments.csv`
- `fold_metrics.csv`
- `logistic_full_data_coefficients.csv`
- `metric_summary.csv`
- `model_selection_decision.json`
- `oof_predictions.csv`
- `permutation_importance_by_fold.csv`
- `permutation_importance_summary.csv`
- `pooled_confusion_matrices.csv`
- `pooled_oof_metrics.csv`
- `preprocessing_parameters.csv`
- `rain_binary_sensitivity_metrics.csv`
- `rq2_centering_values.csv`
- `rq2_specification_results.csv`
- `rq2_interaction_sensitivity.csv`
- `PHASE4B_MODEL_SPECIFICATION.json`
- `PHASE4B_REQUIREMENTS.txt`
- `PHASE4B_README.md`
- `phase4b_modelling.py`.

Expected differences occurred in:

- run timestamps;
- audit-run absolute paths;
- `PHASE4B_ENVIRONMENT.json`;
- `input_checksums.csv`, because several package-control files were not remounted and harmless audit placeholders were used;
- warning timestamps;
- run-log and manifest hashes derived from those time/path differences.

No numerical or procedural discrepancy was found.

---

## Preregistration-Compliance Table

| Requirement | Verdict | Audit evidence |
|---|---|---|
| Canonical Phase 4A authority and hash | Compliant | Filename and SHA-256 hard-coded and verified before fitting |
| Frozen input hash checks | Compliant | Recorded PASS; exact cleaned-data and Phase 3 hashes enforced |
| Target mapping | Compliant | `not fire=0`, `fire=1` |
| Positive class | Compliant | `fire` |
| Primary predictors and order | Compliant | Temperature, RH, Ws, Rain |
| Prohibited FWI-system predictors | Compliant | Not used in RQ1 |
| LOMO folds | Compliant | F06–F09 by complete month |
| Same-date regional grouping | Compliant | Each date appears in one held-out fold |
| Boundary-gap exclusions | Compliant | Exact registered dates and row counts |
| Threshold | Compliant | 0.500000, not tuned |
| Majority baseline | Compliant | Learned from each fold's training counts |
| Raw Rain primary | Compliant | Used in principal logistic model |
| `Rain_any` | Compliant | Logistic sensitivity only; excluded from selection |
| Logistic model | Compliant | Unpenalised statsmodels GLM Binomial-logit, IRLS |
| Decision tree | Compliant | Exact registered parameters and seed |
| Random forest | Compliant | Exact registered parameters and seed |
| Random CV/tuning/calibration/PDP | Compliant | Not implemented |
| Metric definitions | Compliant | All fixed metrics and confusion ordering |
| Aggregation | Compliant | Unweighted mean, sample SD, separate pooled OOF |
| Model-selection rule | Compliant | Exact baseline, practical-tie and SD rules |
| Permutation importance | Compliant | Held-out only, BA score, 30 repeats, fixed seeds |
| RQ2 | Compliant | R0–R3 full-data GLMs; R3 exploratory; one R2–R3 LRT |
| Figure allocation | Compliant | Exactly two Phase 4 figures |
| Failure handling | Compliant | No silent retry or parameter changes |
| Output finalisation | Compliant | Manifest finalised and hashed before run-log append |

---

## Leakage Verdict

**PASS.**

Direct code inspection and preprocessing outputs confirmed:

- each logistic scaler is fitted only on permitted training rows;
- held-out rows are transformed with the unchanged training scaler;
- no imputation, feature selection, tuning or threshold optimisation occurs;
- the baseline majority is learned inside each fold;
- baseline prevalence is stored separately and never thresholded to generate its class;
- raw Rain is the principal representation;
- `Rain_any` is deterministic and sensitivity-only;
- region, date, month and FWI-system variables are excluded from RQ1 predictors;
- held-out outcomes do not select parameters, transformations or models;
- boundary-gap results are excluded from primary model selection.

No leakage route identified in the Phase 4A audit reappeared.

---

## Fold and Baseline Verdict

### Fold structure

| Fold | Primary training | Test | Test fire | Test not fire | Gap exclusions | Gap training |
|---|---:|---:|---:|---:|---:|---:|
| F06 | 184 | 60 | 25 | 35 | 6 rows | 178 |
| F07 | 182 | 62 | 39 | 23 | 12 rows | 170 |
| F08 | 182 | 62 | 51 | 11 | 12 rows | 170 |
| F09 | 184 | 60 | 23 | 37 | 6 rows | 178 |

`fold_assignments.csv` contains 976 rows, exactly 244 source rows × four fold definitions. Every source row has one primary OOF prediction for each of the four primary models. No duplicated model/source-row prediction exists.

### Baseline decisions

| Fold | Training fire | Training not fire | Predicted class |
|---|---:|---:|---|
| F06 | 113 | 71 | fire |
| F07 | 99 | 83 | fire |
| F08 | 87 | 95 | **not fire** |
| F09 | 115 | 69 | fire |

August correctly predicts `not fire`.

### Baseline metrics

Every fold predicts a single class while both true classes are present. Its fold balanced accuracy is therefore exactly 0.5 in every fold:

- mean = 0.500000;
- sample SD = 0.000000.

The pooled predictions are not one globally constant classifier: three month folds predict fire and August predicts not fire. The pooled confusion matrix is:

| Actual \ Predicted | not fire | fire |
|---|---:|---:|
| not fire | 11 | 95 |
| fire | 51 | 87 |

Therefore:

- fire recall = 87/138 = 0.630435;
- not-fire recall = 11/106 = 0.103774;
- pooled balanced accuracy = `(0.630435 + 0.103774)/2 = 0.367104`.

Thus fold-mean balanced accuracy 0.500 and pooled balanced accuracy approximately 0.367 are both mathematically correct; they estimate different aggregations.

All baseline fold metrics, mean/SD values, pooled metrics and confusion counts were independently recomputed with no discrepancy beyond machine precision.

---

## RQ1 Metric Verification

All fold-level metrics and confusion counts were recomputed from `oof_predictions.csv`. Maximum absolute differences were below `6×10^-16`; confusion counts matched exactly.

### Primary balanced accuracy

| Model | June | July | August | September | Four-fold mean | Sample SD | Pooled OOF |
|---|---:|---:|---:|---:|---:|---:|---:|
| Fold-trained baseline | 0.500 | 0.500 | 0.500 | 0.500 | 0.500 | 0.000 | 0.367 |
| Logistic, raw Rain | 0.820 | 0.797 | 0.682 | 0.672 | 0.742 | 0.077 | 0.805 |
| Decision tree | 0.860 | 0.748 | 0.860 | 0.884 | 0.838 | 0.061 | 0.840 |
| Random forest | 0.909 | 0.822 | 0.880 | 0.802 | **0.853** | **0.049** | **0.867** |

### Pooled primary metrics

| Model | Accuracy | BA | Precision | Recall | F1 | ROC-AUC | Average precision |
|---|---:|---:|---:|---:|---:|---:|---:|
| Logistic, raw Rain | 0.811 | 0.805 | 0.819 | 0.855 | 0.837 | 0.895 | 0.915 |
| Decision tree | 0.852 | 0.840 | 0.827 | 0.935 | 0.878 | 0.912 | 0.888 |
| Random forest | **0.873** | **0.867** | **0.869** | 0.913 | **0.890** | **0.944** | 0.934 |

The forest has the highest preregistered fold-mean balanced accuracy. The tree has slightly higher fire recall, while the forest has better specificity and overall balance.

Boundary-gap values were also reproduced exactly. Forest mean BA falls from 0.853 to 0.844; the substantive ordering and conclusion remain stable.

---

## Model-Selection Verification

The independently verified primary mean balanced accuracies are:

- logistic regression: 0.742481;
- decision tree: 0.837947;
- random forest: 0.853108;
- fold-trained baseline: 0.500000.

All three candidates are eligible and exceed the baseline. The forest is 0.015162 above the tree, so the tree is not within the fixed 0.005 practical-tie tolerance. The practical-tie set contains only `random_forest`.

**Recorded decision `random_forest`: confirmed.**

No sensitivity output entered this rule.

---

## Rain-Sensitivity Verdict

The registered `Rain_any` logistic sensitivity reproduced exactly:

| Fold | Balanced accuracy |
|---|---:|
| June | 0.897 |
| July | 0.844 |
| August | 0.870 |
| September | 0.816 |
| Mean | **0.857** |
| Sample SD | 0.035 |
| Pooled OOF | 0.875 |

It has a slightly higher four-fold mean BA than the selected forest by about 0.0035. Excluding it from primary selection is nevertheless correct because Phase 4A fixed raw Rain as the principal representation and explicitly prohibited sensitivity-driven replacement.

The report may state:

> A preregistered binary-rain sensitivity achieved similar, slightly higher out-of-month performance, suggesting that the occurrence of any recorded rain carries more stable label-reproduction information than modelling rainfall amount linearly.

It must also state that:

- this was a sensitivity analysis;
- it did not participate in model selection;
- four folds are too few to claim a reliable superiority;
- it reinforces that the task reproduces a weather-derived class rule rather than independently observed fires.

It would be misleading to call `Rain_any` the selected or best model.

---

## Logistic-Coefficient Verdict

The independently refitted full-data standardised logistic model exactly reproduced all means, scales, coefficients, standard errors, p-values, odds ratios and intervals.

| Predictor | Mean | SD | Beta | SE | OR per SD | 95% OR interval |
|---|---:|---:|---:|---:|---:|---:|
| Temperature | 32.172 | 3.626 | 1.114 | 0.268 | 3.046 | 1.802–5.150 |
| RH | 61.939 | 14.854 | -0.659 | 0.244 | 0.517 | 0.321–0.834 |
| Ws | 15.504 | 2.804 | 0.301 | 0.200 | 1.351 | 0.913–2.000 |
| Rain | 0.761 | 1.995 | -4.932 | 1.097 | 0.00721 | 0.00084–0.0619 |

### Rain diagnostic

The model:

- converged in eight IRLS iterations;
- has full column rank;
- has a low design condition number of about 2.44 after standardisation;
- returned finite coefficients and probabilities;
- does not show exact complete separation.

However, rainfall is zero-heavy and high rainfall is almost entirely associated with `not fire`. One Sidi-Bel Abbes fire-labelled record with Rain = 6.0 mm is highly influential:

- Cook's distance ≈ 2.00;
- removing it changes the standardised Rain coefficient from -4.93 to approximately -12.79.

Therefore, the very small Rain OR is not a stable physical effect estimate. It is a model-based summary of a sharply nonlinear, sparse class pattern under a linear-logit Rain term. It may remain in Figure 5 because it is correctly calculated and the sensitivity analysis addresses representation, but the report must avoid wording such as “a one-SD increase in rainfall reduces real fire odds by 99.3%.” Appropriate wording is that higher recorded Rain is strongly negatively associated with the dataset designation in this fitted model, with magnitude sensitive to sparse influential observations.

---

## Permutation-Importance Verdict

The independent refit reproduced every one of the 480 repeat-level permutation values to within `5×10^-16`.

Confirmed settings:

- primary random forest only;
- held-out month only;
- balanced-accuracy scoring;
- 30 repeats;
- seeds 1406, 1407, 1408 and 1409;
- no training-set or impurity importance;
- negative values retained.

Across-fold results:

| Feature | Mean BA decrease | SD across folds |
|---|---:|---:|
| Rain | **0.2766** | 0.0470 |
| RH | 0.0334 | 0.0508 |
| Temperature | 0.0247 | 0.0325 |
| Ws | **-0.0060** | 0.0157 |

Rain is the only consistently large predictive contribution. Negative wind-speed importance is correctly retained and indicates that permuting Ws sometimes slightly improved held-out balance; it is not evidence of a protective causal effect.

Permutation importance does not feed model selection and is labelled model-dependent and non-causal. This complies with Phase 4A.

---

## RQ2 and Interaction-Model Verdict

### R0–R2 verification

All centring values, design matrices, fits, AIC values and region estimates reproduced independently.

| Model | Region OR | 95% CI | p | AIC |
|---|---:|---:|---:|---:|
| R0 region only | 1.962 | 1.173–3.280 | 0.0102 | 331.342 |
| R1 + Temperature and RH | 0.995 | 0.526–1.881 | 0.9879 | 261.399 |
| R2 + all four weather variables | 1.724 | 0.830–3.577 | 0.1440 | 204.225 |

This correctly supports a specification-dependent result rather than a claim that weather definitively explains the regional association.

### R3 verification

R3 reproduced exactly:

- log-likelihood = -77.4173;
- AIC = 168.835;
- region coefficient = 9.935;
- region OR ≈ 20,644;
- interaction coefficient = 14.101;
- interaction OR per 1 mm ≈ 1.33 million;
- R2-versus-R3 LRT = 37.3906;
- p ≈ `9.67×10^-10`.

### Stability diagnostics

R3:

- converges in ten iterations;
- is full rank;
- has no numerical singularity after column normalisation;
- has no exact infinite coefficient.

Nevertheless, its detailed Wald interpretation is unreliable:

- within Bejaia, no fire-labelled observation has Rain >0.3 mm, while 37 not-fire observations do;
- only four Bejaia fire-labelled records have any Rain;
- fitted probabilities reach approximately `1.9×10^-113`;
- 20 fitted probabilities are below `10^-6`;
- one Sidi fire-labelled observation with 6.0 mm Rain has Cook's distance ≈ 0.90 and standardised residual ≈ 12.5;
- leave-one-out region coefficients range from 8.87 to 12.56;
- leave-one-out interaction coefficients range from 12.15 to 17.61.

This is a sparse, near-separating interaction pattern. The model is not technically invalid under the passed specification, but the enormous ORs are not stable substantive effect sizes.

**R3 classification: valid as an exploratory sensitivity, but too unstable for detailed report use.**

The final report should not foreground its ORs or Wald confidence intervals. A defensible summary is:

> The exploratory Region × Rain term materially improved in-sample fit, but sparse regional rainfall/class combinations produced extreme and influential coefficient estimates, so the interaction is treated as evidence of model instability rather than a precise regional effect.

No replacement model is required for Phase 4B compliance.

---

## Figure Verdict

### Figure 4

**Accepted.**

- Values match `fold_metrics.csv`.
- Model labels and month order are correct.
- Y-axis is fixed at 0–1.
- Baseline and 0.5 reference are shown.
- Rain sensitivity and boundary-gap sensitivity are absent.
- Title uses class-designation reproduction language.
- No clipping or unreadable labels were found.

### Figure 5

**Accepted with an interpretive caution.**

- Values and intervals match `logistic_full_data_coefficients.csv`.
- Predictors are in the registered order.
- The x-axis is logarithmic.
- The OR=1 reference is correct.
- Rain's interval is fully visible.
- The provenance and temporal-dependence qualifications are included.
- No manual editing was detected; regenerated bytes match the manifest.

The report text or caption should additionally note that the Rain coefficient is sensitive to sparse influential observations. This is an interpretation correction, not a figure recalculation.

---

## Output-Manifest Verdict

All required files were supplied. Cross-file checks found:

- README selection = `random_forest`, matching `model_selection_decision.json`;
- specification JSON matches code constants and parameters;
- environment JSON matches requirements;
- warning log contains exactly the two expected August-baseline no-positive conditions;
- fold, pooled and sensitivity tables agree;
- figures are generated from their registered CSV sources;
- RQ2 tables agree with independent fits;
- manifest hash agrees with the run log.

The package is reproducible from the script and frozen input. No analytical file requires replacement.

The only unnecessary package file is:

`__pycache__/phase4b_modelling.cpython-313.pyc`

It should not be carried into the final frozen release.

---

## Exact Blocking Corrections

**None.**

No model, metric, fold, coefficient, importance value, RQ2 calculation or figure requires correction.

---

## Non-blocking Cleanup Suggestions

1. Remove `__pycache__/phase4b_modelling.cpython-313.pyc` from the frozen release.
2. Regenerate `PHASE4B_MANIFEST.csv` without `__pycache__`, calculate its new SHA-256, and update the final manifest-hash block in `PHASE4B_RUN_LOG.txt`. Do not rerun or alter numerical outputs.
3. Preserve the original code-generated PNG bytes matching the manifest; do not use chat-platform-transcoded copies for the frozen package.
4. In the final report, describe `Rain_any` as a preregistered sensitivity, not the selected model.
5. Treat the full-data Rain OR as an unstable model-based association, not a physical or causal effect.
6. Keep R3 exploratory and report its instability rather than foregrounding its extreme ORs.
7. When assembling the final archive, perform one archive-open/list/extract check because the ZIP container itself was not available to this audit runtime.

---

## Confidence Rating

**99%**

The analytical outputs were independently regenerated under the registered environment, all numerical files matched, and the main diagnostics were independently recomputed. The one-point reduction reflects the absence of the actual ZIP container and several original package-control input bytes from the mounted audit runtime; these did not affect the reproduced computations.

---

## Final Gate Decision

# PASS WITH MINOR NON-BLOCKING CORRECTIONS

Phase 4B is analytically accepted. It may be frozen after the package-only cleanup above. No further model fitting or analytical revision is authorised or required.
